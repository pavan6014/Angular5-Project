import { Injectable, Inject, OnInit } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import { DiscountComponent } from '../../main/distributor/discount/discount.component';

@Injectable()
export class AppConfigService implements OnInit {
  public protocol: string;
  public host: string;
  public port: string;
  public url: string;
  public urlConstants: {};
  constructor(@Inject(DOCUMENT) private document) {
      this.protocol = document.location.protocol;
      this.host = document.location.host;
      this.port = document.location.port;
      this.url = 'http://localhost:4200/';
      this.urlConstants = {
        // 'PLM_ADD_USER_FORM_DATA' : '/plm-engine/usermgmt/v0/users/details',
        // 'PLM_ADD_USER_SEARCH_USER_IN_ELDAP' : '/plm-engine/usermgmt/v0/users/searchldapuser',
        // 'PLM_ADD_NEW_USER' : '/plm-engine/usermgmt/v0/users',
        // 'PLM_SEARCH_USER_SEARCH' : '/plm-engine/usermgmt/v0/users/search',
        // 'PLM_UPDATE_USER' : '/plm-engine/usermgmt/v0/users/modify',
        'PLM_ADD_USER_FORM_DATA' : 'data/Admin_user_details.json',
        'PLM_ADD_MARKETING_OFFER_FORM_DATA': 'data/Add_Marketing_Offer_Form.json',        
        'PLM_ADD_USER_SEARCH_USER_IN_ELDAP' : 'data/Admin_Ldap_Search_Response.json',
        'PLM_ADD_NEW_USER' : 'data/Admin_Create_User_Response.json',
        'PLM_SEARCH_USER_SEARCH' : 'data/Admin_Search_User_Response.json',
        'PLM_UPDATE_USER' : 'data/Admin_Search_Modify_User_Response.json',
        'PLM_SEARCH_CRITERIA' : 'data/Search_Criteria.json',
        'PLM_ADD_NEW_PROJECT_FORM': 'data/newProjectRequest.json',
        'PLM_RESPONSE_CREAT': 'data/requesterCreate.json',
        'PLM_PROJECT_DETAILS': 'data/Fetch_All_Projects.json',
        'PLM_PROJECT_DETAILS_ADD_UPDATE': 'data/Fetch_All_Projects_After_Add_Update.json',
        'PLM_MODEL_DETAILS': 'data/requestorModel.json',
        // 'PLM_PSU_OFFER_FOR_PROJECT': 'data/New_Project_Create_PSU.json',
        'PLM_PSU_OFFER_FOR_PROJECT': 'data/Existing_Project_PSU.json',
        'PLM_ADD_UPDATE_PROJECT_RESPONSE': 'data/Add_Update_Project_Response.json',
        'PLM_UPDATE_PROJECT' : 'data/Fetch_Edit_Project_Data.json',
        'PLM_VIEW_PROJECT' : 'data/View_Project.json',
        'PLM_ADD_MARKETING_FORM_BY_OFFER_ID': 'data/Add_Marketing_Offer_Form_By_ID.json',
        'PLM_ADD_MARKETING_OFFER_RESPONSE': 'data/Add_Marketing_Offer_Response.json',
        'PLM_CONFIGURATOR_PROJECT_LIST': 'data/configuratorProjectList.json',
        'PLM_DISCOUNT_ICOMS_STATUS': 'data/discount.json',
        'PLM_PSU_TYPES_MASTER_DATA': 'data/Get_PSU_Type.json',
		    'PLM_CONFIGURATOR_OFFER_CREATION_MASETR_DROPDOWN': 'data/configurator-offer-master_data.json',
        'PLM_CONFIGURATOR_OFFER_CREATION': 'data/configurator-offer-view-edit.json',
        'PLM_DISCOUNT_MASTER_ICOMS_STATUS': 'data/discountMaster.json',
        "PLM_CONFIGURATOR_PSU_OFFERLIST": 'data/configurator-offers-list.json',
        "PLM_TEST_MAIN": 'data/testing-main.json',

        // 'PLM_VIEW_PROJECT' : '/plm-engine/mktproject/v0/viewProj',
        // 'PLM_PSU_TYPES_MASTER_DATA': '/plm-engine/requestor/v0/psuType',
        // 'PLM_PROJECT_DETAILS': '/plm-engine/mktproject/v0/fetchAllProj',
        // 'PLM_UPDATE_PROJECT': '/plm-engine/mktproject/v0/editGetProj',
        // 'PLM_ADD_NEW_PROJECT_FORM': '/plm-engine/mktproject/v0/defaultProjData',
        // 'PLM_ADD_PROJECT': '/plm-engine/mktproject/v0/addNewProj',
        // 'PLM_UPDATE_PROJECT': '/plm-engine/mktproject/v0/editSubmitProj',
        // 'PLM_PSU_OFFER_FOR_PROJECT': '/plm-engine/requester/v0/viewMarketingProj',
        // 'PLM_REMOVE_PSU': '/plm-engine/requester/v0/deleteMarketingoffer',
        // 'PLM_SUBMIT_PROJECT': '/plm-engine/requester/v0/submitmarketingoffer',
        // 'PLM_GET_ADD_MARKETING_FORM_DATA': '/plm-engine/requester/v0/defaultMarketingData',
        // 'PLM_GET_ADD_MARKETING_DATA_BY_OFFERID': '/plm-engine/requester/v0/editGetMarketingOffer',
        // 'PLM_ADD_MARKETING_DATA': '/plm-engine/requester/v0/createMarketingOffers',
        // 'PLM_UPDATE_MARKETING_DATA': '/plm-engine/requester/v0/modifyMarketingOffer',
      };
  }

  ngOnInit() {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.

  }

}
