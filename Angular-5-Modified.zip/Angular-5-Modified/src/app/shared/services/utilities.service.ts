import { Injectable } from '@angular/core';

@Injectable()
export class UtilitiesService {

  constructor() { }

  isEmailAddress(str) {
    const pattern = /^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/
    const testResult = (pattern.test(str));
    if (pattern.test(str)) {
      return true;
    } else {
      return false;
    }
  }

}
