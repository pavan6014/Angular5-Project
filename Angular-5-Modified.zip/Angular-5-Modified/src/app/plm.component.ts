import { Component, OnInit } from '@angular/core';
import { BlockUI, NgBlockUI } from 'ng-block-ui';

@Component({
    selector: 'plm-root',
    templateUrl: './plm.component.html'
})
export class PLMComponent implements OnInit {
    @BlockUI() blockUI: NgBlockUI;
    
    constructor() {
        
    }

    ngOnInit() {
    }
}
