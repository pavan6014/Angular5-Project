import { NgForm} from '@angular/forms';
import { Router } from '@angular/router';
import { routerTransition } from '../router.animations';
import { Component, ViewChild, OnInit } from '@angular/core';

import {
  FormGroup,
  FormControl,
  Validators,
  FormBuilder,
  FormsModule,
  ReactiveFormsModule
} from '@angular/forms';
import { CustomValidators } from './validators/custom-validator.directive';

@Component({
 selector: 'plm-login',
    templateUrl: './login.component.html',
    animations: [routerTransition()]
})
export class LoginComponent implements OnInit {
  private validateForm: FormGroup;

  constructor(private _router: Router, private form: FormBuilder) {
  	this.validateForm = new FormGroup({
      'email': new FormControl('',[Validators.required]),
       'password': new FormControl('', Validators.required),
    });
  }

  ngOnInit() {}

  register(validateForm: NgForm) {
    if ((validateForm.value.email == 'user@cox.com') && (validateForm.value.password == 'cox')) {
      localStorage.setItem('isLoggedin', 'true');
      this._router.navigate(['']);
    } else {
      return false;
    }
    
  }
}