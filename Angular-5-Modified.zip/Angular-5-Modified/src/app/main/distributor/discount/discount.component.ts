import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-discount',
  templateUrl: './discount.component.html'
})
export class DiscountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
