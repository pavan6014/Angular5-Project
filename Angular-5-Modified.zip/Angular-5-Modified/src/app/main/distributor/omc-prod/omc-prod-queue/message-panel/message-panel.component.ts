import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-message-panel',
  templateUrl: './message-panel.component.html'
})
export class MessagePanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
