import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-prod-queue-offer',
  templateUrl: './prod-queue-offer.component.html'
})
export class ProdQueueOfferComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
