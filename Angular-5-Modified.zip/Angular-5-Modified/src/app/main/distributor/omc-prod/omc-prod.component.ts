import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-omc-prod',
  templateUrl: './omc-prod.component.html'
})
export class OmcProdComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
