import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RequestorRoutingModule } from './requestor-routing.module';
import { RequestProcessComponent } from './request-process/request-process.component';
import { CreatePsuComponent, DialogOverviewExampleDialog } from './create-psu/create-psu.component';
import { ProjectDetailComponent } from './request-process/project-detail/project-detail.component';
import { CreateProjectComponent } from './request-process/project-detail/create-project/create-project.component';
import { MarketingOfferBucketComponent } from './create-psu/marketing-offer-bucket/marketing-offer-bucket.component';
import { CreateMarketingOfferComponent } from './create-marketing-offer/create-marketing-offer.component';
import { ViewProjectDetailsComponent } from './view-project-details/view-project-details.component';
import { ProjectListComponent } from './request-process/project-detail/project-list/project-list.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
import { KeysPipe } from './pipes/keys.pipe';
import {MatInputModule} from '@angular/material';
import {MatSelectModule} from '@angular/material/select';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { NguiTabModule } from '@ngui/tab';
import { Ng2PaginationModule } from 'ng2-pagination'; 
import { Ng2OrderModule } from 'ng2-order-pipe';
import { RequestorDataService } from './services/requestor-data.service';
import { SharedModule } from '../../shared/shared.module';
import {MatDialogModule} from '@angular/material/dialog';

@NgModule({
    imports: [
        CommonModule,
        RequestorRoutingModule,
        FormsModule,
        AngularMultiSelectModule,
        MatInputModule,
        MatSelectModule,
        MatDatepickerModule,
        NguiTabModule,
        Ng2PaginationModule,
        Ng2OrderModule,
        SharedModule,
        MatDialogModule
    ],
    declarations: [
        RequestProcessComponent,
        CreatePsuComponent,
        ProjectDetailComponent,
        CreateProjectComponent,
        MarketingOfferBucketComponent,
        CreateMarketingOfferComponent,
        ViewProjectDetailsComponent,
        ProjectListComponent,
        DialogOverviewExampleDialog,
        KeysPipe
    ],
    entryComponents: [DialogOverviewExampleDialog],
    providers: [RequestorDataService]
})
export class RequestorModule {}
