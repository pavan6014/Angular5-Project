import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RequestProcessComponent } from './request-process/request-process.component';
import { CreatePsuComponent } from './create-psu/create-psu.component';
import { CreateMarketingOfferComponent } from './create-marketing-offer/create-marketing-offer.component';
import { ViewProjectDetailsComponent } from './view-project-details/view-project-details.component';

const routes: Routes = [
    { path: '', component: RequestProcessComponent },
    { path: 'create-psu', component: CreatePsuComponent },
    { path: 'add-marketing-offer', component: CreateMarketingOfferComponent},
    { path: 'view-project-details', component: ViewProjectDetailsComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RequestorRoutingModule { }
