import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { AppConfigService } from '../../../shared/services/app-config.service';
import { BreadCrumb } from '../../../shared/services/bread-crumb';
import { RequestorResponseInterface, AddUpdateProjectResponse, ViewMarketingProjResponse } from '../requestor.interface';

@Injectable()
export class RequestorService {
    private breadCrumbs: BreadCrumb[];

    public constructor(
        private http: HttpClient,
        private appConfigService: AppConfigService
    ) {}

    getBreadCrumbs(): BreadCrumb[] {
        return [
            { name: 'Home', url: 'dashboard' },
            { name: ' PLM Work Flow ', url: '' },
            { name: 'Requestor', url: '' }
        ];
    }

    getCreateUpdateProjectFormData(): Observable<RequestorResponseInterface> {
        // const getCreateUpdateProjectFormDataURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_UPDATE_PROJECT'];
        // return this.http
        //   .get(getCreateUpdateProjectFormDataURL)
        //   .map((response: any) => {
        //     return response;
        //   })
        //   .catch(this.handleError);
        const getUserDetailsURL = this.appConfigService.urlConstants[
            'PLM_ADD_NEW_PROJECT_FORM'
        ];
        return this.http
            .get(getUserDetailsURL)
            .map((response: Response) => {
                return response;
            })

            .catch(this.handleError);
    }

    // postAllProjectRequest(): Observable<Addrequestor> {
    //     const postUserDetailsURL = this.appConfigService.urlConstants[
    //         'PLM_RESPONSE_CREAT'
    //     ];
    //     return this.http
    //         .get(postUserDetailsURL)
    //         .map((response: Response) => {
    //             return response;
    //         })

    //         .catch(this.handleError);
    // }

    getEditProjectData(projectCode){
        // const getViewProjectData = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_UPDATE_PROJECT'] +'/'+projectCode;
        // return this.http
        //   .get(getViewProjectData)
        //   .map((response: any) => {
        //     return response;
        //   })
        //   .catch(this.handleError);
        const getUpdateProjectURL = this.appConfigService.urlConstants[
            'PLM_UPDATE_PROJECT'
        ];
        return this.http
            .get(getUpdateProjectURL)
            .map((response: Response) => {
                return response;
            })

            .catch(this.handleError);
    }

    getViewProjectData(reqObj) {
        // const getViewProjectData = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_VIEW_PROJECT'];
        // return this.http
        //   .get(getViewProjectData, reqObj)
        //   .map((response: any) => {
        //     return response;
        //   })
        //   .catch(this.handleError);
        const getUpdateProjectURL = this.appConfigService.urlConstants[
            'PLM_VIEW_PROJECT'
        ];
        return this.http
            .get(getUpdateProjectURL)
            .map((response: Response) => {
                return response;
            })

            .catch(this.handleError);
    }

    getAllProjectDetails(): Observable<any> {
        // const getProjectDetailsURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_PROJECT_DETAILS'];
        // return this.http
        //   .get(getProjectDetailsURL)
        //   .map((response: any) => {
        //     return response;
        //   })
        //   .catch(this.handleError);
        const getProjectDetailsURL = this.appConfigService.urlConstants[
            'PLM_PROJECT_DETAILS'
        ];
        return this.http
            .get(getProjectDetailsURL)
            .map((response: Response) => {
                return response;
            })

            .catch(this.handleError);
    }

    // getAllProjectDetailsAddUpdate(): Observable<any> {
    //     // const getUserList = this.appConfigService.protocol + '://' + this.appConfigService.host + ':' + this.appConfigService.port + '/' + this.appConfigService.urlConstants['PLM_PROJECT_DETAILS'];
    //     // return this.http
    //     //   .post(getUserDetailsURL, searchCriteria)
    //     //   .map((response: Response) => {
    //     //     return response;
    //     //   })
    //     //   .catch(this.handleError);
    //     const getProjectDetailsURL = this.appConfigService.urlConstants[
    //         'PLM_PROJECT_DETAILS_ADD_UPDATE'
    //     ];
    //     return this.http
    //         .get(getProjectDetailsURL)
    //         .map((response: Response) => {
    //             return response;
    //         })

    //         .catch(this.handleError);
    // }

    // getAllRequestorModel(): Observable<Addrequestor> {
    //     const getProjectModelDetailsURL = this.appConfigService.urlConstants[
    //         'PLM_MODEL_DETAILS'
    //     ];
    //     return this.http
    //         .get(getProjectModelDetailsURL)
    //         .map((response: Response) => {
    //             return response;
    //         })

    //         .catch(this.handleError);
    // }

    postAddProjectDetails(reqObj):Observable<AddUpdateProjectResponse>{
        //console.log('Post Project Details --> '+reqObj);
        //console.log(JSON.stringify(reqObj));
        // const postAddProjectDetailsURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_ADD_PROJECT'];
        // return this.http
        //   .post(postAddProjectDetailsURL, reqObj)
        //   .map((response: Response) => {
        //     return response;
        //   })
        //   .catch(this.handleError);
        const getAddUpdateProject = this.appConfigService.urlConstants[
            'PLM_ADD_UPDATE_PROJECT_RESPONSE'
        ];
        return this.http
            .get(getAddUpdateProject)
            .map((response: Response) => {
                return response;
            })

            .catch(this.handleError);
    }

    
    postUpdateProjectDetails(reqObj):Observable<AddUpdateProjectResponse>{
        //console.log('Post Project Details --> '+reqObj);
        //console.log(JSON.stringify(reqObj));
        // const postAddProjectDetailsURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_UPDATE_PROJECT'];
        // return this.http
        //   .put(postAddProjectDetailsURL, reqObj)
        //   .map((response: Response) => {
        //     return response;
        //   })
        //   .catch(this.handleError);
        const getAddUpdateProject = this.appConfigService.urlConstants[
            'PLM_ADD_UPDATE_PROJECT_RESPONSE'
        ];
        return this.http
            .get(getAddUpdateProject)
            .map((response: Response) => {
                return response;
            })

            .catch(this.handleError);
    }

    getPSUTypes(){
        // const getPSUTypes = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_PSU_TYPES_MASTER_DATA'];
        // return this.http
        //   .get(getPSUTypes)
        //   .map((response: any) => {
        //     return response;
        //   })
        //   .catch(this.handleError);
        const getPSUTypesURL = this.appConfigService.urlConstants[
            'PLM_PSU_TYPES_MASTER_DATA'
        ];
        return this.http
            .get(getPSUTypesURL)
            .map((response: Response) => {
                return response;
            })
            .catch(this.handleError);
    }

    private handleError(error: Response) {
        return Observable.throw(error.statusText);
    }
}
