import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-project-detail',
  templateUrl: './project-detail.component.html'
})
export class ProjectDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
