import { Component, OnInit, Input, Output, EventEmitter, ElementRef, OnChanges, SimpleChanges, SimpleChange } from '@angular/core';
import { Router } from '@angular/router';
import { ViewAddMrktingOfferModel } from '../../requestor.interface';
import { RequestorDataService } from '../../services/requestor-data.service';

@Component({
  selector: 'plm-marketing-offer-bucket',
  templateUrl: './marketing-offer-bucket.component.html'
})
export class MarketingOfferBucketComponent implements OnInit, OnChanges {

  @Input() projectCode: string;
  @Input() psu: ViewAddMrktingOfferModel;
  @Input() psuType: string;
  @Input() psuCount: number;
  @Input() psuTypes: Map<string, string>;
  @Output() removeOffer: EventEmitter<ViewAddMrktingOfferModel> = new EventEmitter<ViewAddMrktingOfferModel>();
  private isDataProduct: boolean;
  private dataProductVal: string;
  private isVideoProduct: boolean;
  private videoProductVal: string;
  private isPhoneProduct: boolean;
  private phoneProductVal: string;
  private isHomeProduct: boolean;
  private homeProductVal: string;
  private productsConfigured: boolean;
  private selected: string[];
  private productsArray: string[];
  private noDataArray: string[];
  private disabledAddMO: Boolean;

  constructor(private requestorDataService: RequestorDataService, private router: Router, private elRef: ElementRef) {
    this.isDataProduct = false;
    this.isPhoneProduct = false;
    this.isVideoProduct = false;
    this.isHomeProduct = false;
    this.productsArray = [];
    this.noDataArray = [];
    this.disabledAddMO = true;
  }

  ngOnInit() {
    const products = this.psu.moProductDataModel;
    for (let i=0; i<products.length; i++) {
      this.productsArray.push(this.capitalizeFirstLetter(products[i].psuTypeMasterModel.psuName));
      this.showProducts(products[i]);
    }    
    this.selected = this.productsArray;
    for (let j=0; j<this.psuCount; j++) {
      this.noDataArray.push('No Data');
    }
    this.psu.psuType = this.psuType;
  }

  ngOnChanges(changes: SimpleChanges) {
    const psuTypes: SimpleChange = changes.psuTypes;
    if (typeof psuTypes.currentValue !== 'undefined') {
        this.psuTypes = psuTypes.currentValue;
    }
  }

  showProducts(product) {
    if (product.psuTypeMasterModel.psuName === 'Data') {
      this.isDataProduct = true;
      this.dataProductVal = product.psuTypeMasterModel.psuName;
    } else if (product.psuTypeMasterModel.psuName === 'Phone') {
      this.isPhoneProduct = true;
      this.phoneProductVal = product.psuTypeMasterModel.psuName;
    } else if (product.psuTypeMasterModel.psuName === 'Video') {
      this.isVideoProduct = true;
      this.videoProductVal = product.psuTypeMasterModel.psuName;
    } else if (product.psuTypeMasterModel.psuName === 'Home') {
      this.isHomeProduct = true;
      this.homeProductVal = product.psuTypeMasterModel.psuName;
    } else {
    }
  }
  
  checkToDisable(productTypeSelect, selectedVal) {
    console.log(productTypeSelect);
    console.log(selectedVal);
    if (Number(this.selected.length) == this.psuCount) {
      this.productsConfigured = true;
      productTypeSelect.close();
      this.disabledAddMO = false;
    } else {
      this.disabledAddMO = true;
    }
    this.psu.moProductDataModel = [];
    for (let i=0; i<this.selected.length; i++) {
      console.log(this.selected[i]);
      const productData = {
        'prodDataId': '',
        'prodDetail': '',
        'psuType': '',
        'mrktingOfferTxnDetModel': null,
        'psuTypeMasterModel': {
            'psuTypeId': this.psuTypes[this.selected[i].toUpperCase()],
            'psuName': this.selected[i],
            'description': ''
        }
    }
      this.psu.moProductDataModel.push(productData);
      this.showProducts(productData);
    }
    const noDataArrayCount = Number(this.psuCount) - Number(this.selected.length);
    this.noDataArray = [];
    for (let j=0; j<noDataArrayCount; j++) {
      this.noDataArray.push('No Data');
    }
    this.selected = selectedVal;  
  }

  enableProductTypeSelect(data){
    const selectedVal = JSON.parse(JSON.stringify(this.selected));
    for (let i=0; i<this.psu.moProductDataModel.length; i++) {
        if (this.capitalizeFirstLetter(this.psu.moProductDataModel[i].psuTypeMasterModel.psuName) == data) {
          this.psu.moProductDataModel.splice(i, 1);
          selectedVal.splice(i, 1);
        }
    }
    this.selected = selectedVal;
    this['is'+ data +'Product'] = false;
    this.productsConfigured = false;
    const noDataArrayCount = Number(this.psuCount) - Number(this.selected.length);
    this.noDataArray = [];
    for (let j=0; j<noDataArrayCount; j++) {
      this.noDataArray.push('No Data');
    }
    if (Number(this.selected.length) == this.psuCount) {
      this.disabledAddMO = false;
    } else {
      this.disabledAddMO = true;
    }
  }

  capitalizeFirstLetter(product) {
    const productVal = product.toLowerCase().replace(/\b[a-z]/g, function(letter) {
        return letter.toUpperCase();
    });
    return productVal;
  }

  removePSU(offerID){
    this.removeOffer.emit(this.psu);
  }

  modifyPSU(offerID){
    this.triggerAddModifyPSU(offerID);
  }

  addPSU(offerID){
    this.triggerAddModifyPSU(offerID);
  }

  triggerAddModifyPSU(offerID) {
    this.requestorDataService.addMarketingFormData = this.psu;
    this.requestorDataService.addMarketingFormData.projectCode = this.projectCode;
    this.router.navigate(['/plm-work-flow/requestor/add-marketing-offer']);
  }
}
