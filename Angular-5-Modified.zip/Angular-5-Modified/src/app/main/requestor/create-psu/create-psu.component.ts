import { Component, OnInit, ElementRef, ViewChild, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { RequestorService } from '../services/requestor.service';
import { RequestorDataService } from '../services/requestor-data.service';
import { ViewAddMrktingOfferModel, SubmitProjectInfo } from '../requestor.interface';
import { CreatePsuService } from './create-psu.service';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';

@Component({
  selector: 'plm-create-psu',
  templateUrl: './create-psu.component.html',
  styleUrls: ['./create-psu.component.css'],
  providers: [CreatePsuService, RequestorService]
})
export class CreatePsuComponent implements OnInit {

  private psu1P: ViewAddMrktingOfferModel[];
  private psu2P: ViewAddMrktingOfferModel[];
  private psu3P: ViewAddMrktingOfferModel[];
  private psu4P: ViewAddMrktingOfferModel[];
  private psu: any;
  private removePSUType: string;
  private addModifyPSUType: string;
  private offerRemoved: boolean;
  private projectCode: string;
  private disableSubmit: boolean;
  private disable1PAddNew: Boolean;
  private disable2PAddNew: Boolean;
  private disable3PAddNew: Boolean;
  private disable4PAddNew: Boolean;
  private psuTypes: Map<string, string>;

  @ViewChild('successModal') successModal: ElementRef;

  constructor(private requestorService: RequestorService, private requestorDataService: RequestorDataService, private createPsuService: CreatePsuService, private router: Router, public dialog: MatDialog) {
    this.psu1P = [];
    this.psu2P = [];
    this.psu3P = [];
    this.psu4P = [];
    this.offerRemoved = false;
    this.disableSubmit = false;
    this.disable1PAddNew = false;
    this.disable2PAddNew = false;
    this.disable3PAddNew = false;
    this.disable4PAddNew = false;
  }

  openDialog(): void {
    let dialogRef = this.dialog.open(DialogOverviewExampleDialog, {
      width: 'auto'
    });

    dialogRef.afterClosed().subscribe(result => {
      //console.log('The dialog was closed');
    });
  }

  ngOnInit() {
    this.getProjectList();
    this.getPSUTypes();
  }

  getProjectList(){
    this.createPsuService.getProjectPSUData(this.requestorDataService.createPSUProjectID).subscribe(
      data => {
        this.projectCode = data.projectCode;
        this.psu1P = data.mrktingOfferModelMap['1P'];
        this.psu2P = data.mrktingOfferModelMap['2P'];
        this.psu3P = data.mrktingOfferModelMap['3P'];
        this.psu4P = data.mrktingOfferModelMap['4P'];
        this.enableDisableSubmitButton();
        console.log(this.requestorDataService.createPSUProjectID);
      },
      error => {
        console.log('Error :: ' + error)
      }
    );
  }

  getPSUTypes(){
    this.createPsuService.getPSUTypes().subscribe(
      data => {
        this.psuTypes = data;
      },
      error => {
        console.log('Error :: ' + error)
      }
    );
  }

  enableDisableSubmitButton(){
    const psuArray = [this.psu1P, this.psu2P, this.psu3P, this.psu4P];
    for (const psu of psuArray) {
      const currentPSU = psu;
      if (!this.iteratePSUForUnConfigured(currentPSU)) {
         this.disableSubmit = true;
         break;
      } else {
         this.disableSubmit = false;
      }
    }
  }

  iteratePSUForUnConfigured(currentPSU){
    let result = true;
    for (let i=0; i< currentPSU.length; i++) {
        const currentPSUVal = currentPSU[i];
        if (currentPSUVal.moId === 'No Offer ID') {
          result = false;
          break;
        }
    }
    return result;
  }

  addPSU(psuType) {
    let psuObj: ViewAddMrktingOfferModel;
    psuObj = {
      'moId': 'No Offer ID',
      'projectCode': '',
      'createdBy': '',
      'createdDate': 0,
      'description': '',
      'discValue': '',
      'endDate': '',
      'modifiedDate': 0,
      'offerType': '',
      'price': 0,
      'priceSpec': '',
      'startDate': '',
      'discountTypeId': 0,
      'discountRule': '',
      'psuType': '',
      'bundleType': '',
      'moProductDataModel': [],
      'currencyId': '',
      'bundleMasterModel': {
        'bndlId': 0,
        'bndlName': ''
      },
      'currencyMasterModel': null,
      'mktOffrDiscountMasterModel': {
        'discTypeId': '',
        'discTypeName': ''
      }
    }
    this['psu' + psuType].push(psuObj);
    console.log('psu' + psuType);
    console.log(this['psu' + psuType]);
    this.enableDisableSubmitButton();
    this.disable1PAddNew = false;
    this.disable2PAddNew = false;
    this.disable3PAddNew = false;
    this.disable4PAddNew = false;
    if (!this.iteratePSUForUnConfigured(this['psu' + psuType])) {
      this['disable' + psuType +'AddNew'] = true;
    }
  }

  onRemoveOffer(removePSURequest: ViewAddMrktingOfferModel) {
    this.removePSUType = removePSURequest.psuType.toUpperCase();
    console.log(removePSURequest);
    if (removePSURequest.moId === 'No Offer ID') {
      this['psu' + removePSURequest.psuType].pop();
      this.offerRemoved = true;
      this.enableDisableSubmitButton();
      if (!this.iteratePSUForUnConfigured(this['psu' + removePSURequest.psuType])) {
        this['disable' + removePSURequest.psuType +'AddNew'] = true;
      } else {
        this['disable' + removePSURequest.psuType +'AddNew'] = false;
      }
      return false;
    }
    this.createPsuService.removePSU(removePSURequest.projectCode, removePSURequest.moId).subscribe(
      data => {
        this.offerRemoved = true;
        this.getProjectList();
        this.enableDisableSubmitButton();
      },
      error => {
        //console.log('Error :: ' + error)
      }
    );
  }
//  response start
  submitRequestor(){
    this.createPsuService.submitProject(this.projectCode).subscribe(
      data => {
        this.openDialog();
      },
      error => {
        console.log('Error :: ' + error)
      }
    );
  }

  returnBack(){
    this.router.navigate(['/plm-work-flow/requestor']);
  }
}

@Component({
  selector: 'configurator-confirmation-dialog',
  templateUrl: './configurator-confirmation-dialog.html'
})
export class DialogOverviewExampleDialog {

  constructor(
    public dialogRef: MatDialogRef<DialogOverviewExampleDialog>, private router: Router, 
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onNoClick(): void {
    this.dialogRef.close();
  }

  moveToDashboard(){
    this.dialogRef.close();
    this.router.navigate(['']);
  }

}


