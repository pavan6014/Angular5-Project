import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/empty';
import 'rxjs/add/operator/retry';
import { ViewMarketingProjResponse, ViewAddMrktingOfferModel } from '../requestor.interface';
import { BreadCrumb } from '../../../shared/services/bread-crumb';
import { AppConfigService } from '../../../shared/services/app-config.service';

@Injectable()
export class CreatePsuService {

  constructor(private http: HttpClient, private appConfigService: AppConfigService) { }

  getProjectPSUData(projectCode): Observable<ViewMarketingProjResponse> {
    // const getProjectPSUDataURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_PSU_OFFER_FOR_PROJECT'] + '/' +projectCode;
    // return this.http
    //   .get(getProjectPSUDataURL)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
    const getUserDetailsURL = this.appConfigService.urlConstants['PLM_PSU_OFFER_FOR_PROJECT'];
    return this.http
      .get(getUserDetailsURL)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }

  getPSUTypes():Observable<Map<string, string>>{
    // const getPSUTypes = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_PSU_TYPES_MASTER_DATA'];
    // return this.http
    //   .get(getPSUTypes)
    //   .map((response: any) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
    const getPSUTypesURL = this.appConfigService.urlConstants[
        'PLM_PSU_TYPES_MASTER_DATA'
    ];
    return this.http
      .get(getPSUTypesURL)
      .map((response: Response) => {
          return response;
      })
      .catch(this.handleError);
  }

  removePSU(projectCode, moID): Observable<ViewAddMrktingOfferModel> {
    // const removePSUURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_REMOVE_PSU'] + '/' +projectCode + '/' +moID;
    // return this.http
    //   .delete(removePSUURL)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
    const getUserDetailsURL = this.appConfigService.urlConstants['PLM_REMOVE_PSU'];
    return this.http
      .get(getUserDetailsURL)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }

  // addPSU(reqObj): Observable<CreatePsu> {
  //   // const getUserDetailsURL = this.appConfigService.protocol + '://' + this.appConfigService.host + ':' + this.appConfigService.port + '/' + this.appConfigService.urlConstants['PLM_ADD_NEW_USER'];
  //   // return this.http
  //   //   .post(getUserDetailsURL, reqObj)
  //   //   .map((response: Response) => {
  //   //     return response;
  //   //   })
  //   //   .catch(this.handleError);
  //   const getUserDetailsURL = this.appConfigService.urlConstants['PLM_ADD_NEW_USER'];
  //   return this.http
  //     .get(getUserDetailsURL)
  //     .map((response: Response) => {
  //       return response;
  //     })
  //     .catch(this.handleError);
  // }

  // modifyPSU(reqObj): Observable<CreatePsu> {
  //   // const getUserDetailsURL = this.appConfigService.protocol + '://' + this.appConfigService.host + ':' + this.appConfigService.port + '/' + this.appConfigService.urlConstants['PLM_ADD_NEW_USER'];
  //   // return this.http
  //   //   .post(getUserDetailsURL, reqObj)
  //   //   .map((response: Response) => {
  //   //     return response;
  //   //   })
  //   //   .catch(this.handleError);
  //   const getUserDetailsURL = this.appConfigService.urlConstants['PLM_ADD_NEW_USER'];
  //   return this.http
  //     .get(getUserDetailsURL)
  //     .map((response: Response) => {
  //       return response;
  //     })
  //     .catch(this.handleError);
  // }

  submitProject(projectCode): Observable<any> {
     // const submitProjectURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_SUBMIT_PROJECT'] + '/' +projectCode;
    // return this.http
    //   .get(submitProjectURL)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
    const getUserDetailsURL = this.appConfigService.urlConstants['PLM_SUBMIT_PROJECT'];
    return this.http
      .get(getUserDetailsURL)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }

  private handleError(error: Response) {
    return Observable.throw(error.statusText);
  }

}
