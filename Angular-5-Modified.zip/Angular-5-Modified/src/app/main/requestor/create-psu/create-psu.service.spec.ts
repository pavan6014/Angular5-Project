import { TestBed, inject } from '@angular/core/testing';

import { CreatePsuService } from './create-psu.service';

describe('CreatePsuService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CreatePsuService]
    });
  });

  it('should be created', inject([CreatePsuService], (service: CreatePsuService) => {
    expect(service).toBeTruthy();
  }));
});
