import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ModifyMarketingOffer } from '../requestor.interface';
import { GetMarketingOffer } from './create-marketing-offer.interface';
import { CreateMarketingOfferService } from './create-marketing-offer.service';
import { RequestorDataService } from '../services/requestor-data.service';

@Component({
  selector: 'plm-create-marketing-offer',
  templateUrl: './create-marketing-offer.component.html',
  providers: [CreateMarketingOfferService]
})
export class CreateMarketingOfferComponent implements OnInit {

  private modifyMOData: ModifyMarketingOffer;
  private projectCode: string;
  private offerCode: string;
  private showDataField: Boolean;
  private showPhoneField: Boolean;
  private showVideoField: Boolean;
  private showHomeField: Boolean;
  private offer: GetMarketingOffer;
  private formDataLoaded: Boolean;
  private getAddMarketingOfferFormData: any;
  private errorSubmittingOfferForm: Boolean;
  private productsTypeConcatenated: string;
  private psuTypes: Map<string, string>;

  constructor(private createMarketingOfferService: CreateMarketingOfferService, private router: Router, private requestorDataService: RequestorDataService) {
    this.getAddMarketingOfferFormFields();
    this.showDataField = false;
    this.showHomeField = false;
    this.showPhoneField = false;
    this.showVideoField = false;
    this.formDataLoaded = false;
    this.errorSubmittingOfferForm = false;
    this.productsTypeConcatenated = '';
  }

  ngOnInit() {
    const addMarketingFormData = this.requestorDataService.addMarketingFormData;
    this.psuTypes = this.requestorDataService.psuTypes;
    this.projectCode = '';
    this.offer = this.getInitalOfferData();
    let productsArray: string[];
    productsArray = [];
    if (typeof addMarketingFormData !== 'undefined') {
      this.projectCode = addMarketingFormData.projectCode;
      for (let i = 0; i < addMarketingFormData.moProductDataModel.length; i++) {
        const psuName = addMarketingFormData.moProductDataModel[i].psuTypeMasterModel.psuName;
        const currentPSUName = (psuName === 'Home') ? (psuName.toUpperCase()+'LIFE') : (psuName.toUpperCase()); 
        productsArray.push(this.capitalizeFirstLetter(currentPSUName));
      }
      this.showHidePSUFormsFields(productsArray);
      this.intializeAddMarketingOffer(addMarketingFormData);
    }
  }

  capitalizeFirstLetter(product) {
    const productVal = product.toLowerCase().replace(/\b[a-z]/g, function(letter) {
        return letter.toUpperCase();
    });
    console.log(productVal);
    return productVal;
  }

  showHidePSUFormsFields(productsArray) {
    const productList = ['Data', 'Phone', 'Video', 'Homelife'];
    let offerTypeString = '';
    for (let i = 0; i < productList.length; i++) {
      if (productsArray.indexOf(productList[i]) > -1) {
        this['show' + productList[i] + 'Field'] = true;
        if (i == 0) {
          offerTypeString += productList[i];
        } else {
          offerTypeString += '/' + productList[i];
        }
      }
    }
    this.productsTypeConcatenated = offerTypeString;
  }

  getAddMarketingOfferFormFields() {
    this.createMarketingOfferService.getAddMarketingOfferFormData(this.projectCode)
      .subscribe(
        data => {
          this.getAddMarketingOfferFormData = data;
          this.getAddMarketingOfferFormData.bundleType = {
            'gold': 'Gold',
            'silver': 'Silver',
            'bronze': 'Bronze'
          };
          this.formDataLoaded = true;
        },
        error => {
          console.log('Error :: ' + error)
        }
      );
  }

  getProductData(product){
    const productID = this.requestorDataService.psuTypes[product];
    return this.getAddMarketingOfferFormData.psuTypeDetailModelMap[productID];
  }

  intializeAddMarketingOffer(addMarketingFormData) {
    if (addMarketingFormData.offerID != 'No Offer ID') {
      const reqObj = {
        'offerID': addMarketingFormData.moId
      };
      this.createMarketingOfferService.getAddMarketingDateForOfferId(this.projectCode, addMarketingFormData.moId).subscribe(
        data => {
          this.modifyMOData = data;
          this.offer = this.getModifyMOData();
          this.offer.offerType = addMarketingFormData.psuType + '-' + this.productsTypeConcatenated;
        },
        error => {
          console.log('Error :: ' + error)
        }
      );
    } else {
      this.offer = this.getInitalOfferData();
      this.offer.offerType = addMarketingFormData.psuType + '-' + this.productsTypeConcatenated;
    }
  }

  getModifyMOData(){
    return {
      'offerCode': this.modifyMOData.mrktingOfferModel[0].moId,
      'offerType': this.modifyMOData.mrktingOfferModel[0].offerType,
      'bundleType': this.modifyMOData.mrktingOfferModel[0].bundleType,
      'offerStartDate': this.modifyMOData.mrktingOfferModel[0].startDate,
      'offerEndDate': this.modifyMOData.mrktingOfferModel[0].endDate,
      'offerDescription': this.modifyMOData.mrktingOfferModel[0].description,
      'dataProductType': this.getProductID('DATA'),
      'phoneProductType': this.getProductID('PHONE'),
      'videoProductType': this.getProductID('VIDEO'),
      'homelifeProductType': this.getProductID('HOMELIFE'),
      'price':  this.modifyMOData.mrktingOfferModel[0].price.toString(),
      'priceSpec':  this.modifyMOData.mrktingOfferModel[0].priceSpec,
      'discountType':  this.modifyMOData.mrktingOfferModel[0].discountTypeId.toString(),
      'discountValue':  this.modifyMOData.mrktingOfferModel[0].discValue,
      'discountDuration': '',
      'discountRule':  this.modifyMOData.mrktingOfferModel[0].discountRule
    };
  }

  getProductID(productType){
    let result = '';
    for (let i=0; i<this.modifyMOData.mrktingOfferModel[0].moProductDataModel.length; i++) {
      const currentProduct = this.modifyMOData.mrktingOfferModel[0].moProductDataModel[i];
      if (currentProduct.psuTypeMasterModel.psuName === productType) {
        result = currentProduct.prodDataId;
        break;
      }
    }
    return result;
  }

  getInitalOfferData() {
    return {
      'offerCode': '',
      'offerType': '',
      'bundleType': '',
      'offerStartDate': '',
      'offerEndDate': '',
      'offerDescription': '',
      'dataProductType': '',
      'phoneProductType': '',
      'videoProductType': '',
      'homelifeProductType': '',
      'price': '',
      'priceSpec': '',
      'discountType': '',
      'discountValue': '',
      'discountDuration': '',
      'discountRule': ''
    };
  }


  onSubmit() {
    this.errorSubmittingOfferForm = false;
    this.createMarketingOfferService.postAddMarketingOfferFormData(this.getSubmitData()).subscribe(
      data => {
        if (data.actionStatus == 'SUCCESS') {
          this.router.navigate(['/plm-work-flow/requestor/create-psu']);
        } else {
          this.errorSubmittingOfferForm = true;
        }
      },
      error => {
        console.log('Error :: ' + error)
      }
    );
  }

  getSubmitData() {
    let offerCodeVal = (this.offer.offerCode) ? (this.offer.offerCode): '';
    const result = {
      'projectCode': this.projectCode,
      'offerId': offerCodeVal,
      'offerStartDate': this.getDateInFormat(this.offer.offerStartDate),
      'offerEndDate': this.getDateInFormat(this.offer.offerEndDate),
      'offerType': this.offer.offerType,
      'offerDescription': this.offer.offerDescription,
      'price': this.offer.price,
      'priceSpec': this.offer.priceSpec,
      'discountValue': this.offer.discountValue,
      'discountTypeId': this.offer.discountType,
      'discountRule': this.offer.discountRule,
      'psuType': this.requestorDataService.addMarketingFormData.psuType,
      'bundleType': this.offer.bundleType,
      'psyTypeModelList': this.getProductsArray(),
      'currencyId': ''
    }
    return result;
  }

  getDateInFormat(date) {
    const currentDate = new Date(date);
    const result = currentDate.getFullYear() + '-' + currentDate.getMonth() + '-' + currentDate.getDate() + ' ' + currentDate.getHours() + ':' + currentDate.getMinutes() + ':' + currentDate.getSeconds();
    return result;
  }

  getProductsArray() {
    let productsArray = [];
    const productList = ['Data', 'Phone', 'Video', 'Home'];
    let offerTypeString = '';
    for (let i = 0; i < productList.length; i++) {
      const currentProduct = (productList[i] === 'Home') ? (productList[i].toUpperCase()+'LIFE') : (productList[i].toUpperCase()); 
      if (this['show' + productList[i] + 'Field']) {
        const productObj = {
          'psuTypeGroupId': this.requestorDataService.psuTypes[currentProduct],
          'psuTypeId': this.offer[productList[i].toLowerCase()+'ProductType'],
          'description': '',
          'psuName': this.getPSUName(this.requestorDataService.psuTypes[currentProduct], this.offer[currentProduct.toLowerCase()+'ProductType'])
        }
        productsArray.push(productObj);
      }
    }
    return productsArray;
  }

  getPSUName(psuIDArray, productID){
    let psuArray = this.getAddMarketingOfferFormData.psuTypeDetailModelMap[psuIDArray];
    for (let i=0; i<psuArray.length; i++) {
      if (Number(psuArray[i].psuTypeId) === Number(productID)) {
        return psuArray[i].psuName;
      }
    }
    return '';
  }

  returnBack() {
    this.router.navigate(['/plm-work-flow/requestor/create-psu']);
  }

}
