export interface GetMarketingOffer {
  offerCode: string;
  offerType: string;
  bundleType: string;
  offerStartDate: string;
  offerEndDate: string;
  offerDescription: string;
  dataProductType: string;
  phoneProductType:string;
  videoProductType:string;
  homelifeProductType:string;
  price: string;
  priceSpec: string;
  discountType: string;
  discountValue: string;
  discountDuration: string;
  discountRule: string;
}


export interface GetMarketingOffersResponse {
  actionResult: string;
  actionStatus: string;
  getMarketingOffers: GetMarketingOffer;
}

export interface SubmitAddMarketingOfferResponse {
  actionResult: string;
  actionStatus: string;
  projectCode: string;
}