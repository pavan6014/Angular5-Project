// Poorna Started New InterFace Created from Here 

//Requestor Request Interface
export interface RequestorRequestInterface {
    projectCode: string;
    projectType: string;
    projectStatus: string;
    projectStartDt: string;
    projectEndDt: string;
    description: string;
    market: Markets[];
    status: string;
    assignedTo: string;
    sites: string[];
    mapProjectTypes: Map<string, string>;
    mapMarketList: Map<string, string>;
    intakeFormResp: IntakeFormReq;
}

//Requestor Response Interface
export interface RequestorResponseInterface {
    actionResult: string;
    actionStatus: string;
    projectCode: string;
    projectType: string;
    projectStatus: string;
    projectStartDt: string;
    projectEndDt: string;
    description: string;
    market: Markets[];
    status: string;
    assignedTo: string;
    sites: string[];
    mapProjectTypes: Map<string, string>;
    mapMarketList: Map<string, string>;
    intakeFormResp: IntakeFormResp;
}

//Intake Request Interface
export interface IntakeFormReq {
    intakeFormId: string;
    addUptierPaths: string;
    description: string;
    durationMonths: string;
    instltnIncFlg: boolean;
    instltnPricing: string;
    prodMustExc: string;
    prodMustInc: string;
    prodMustInstlExc: string;
    prodMustInstlInc: string;
    prodMustRetainExc: string;
    prodMustRetainInc: string;
    products: string;
    projectName: string;
    reqstdExpireDate: string;
    reqstdStartDate: string;
    reqstorEmail: string;
    reqstorName: string;
    stepupAmount: string;
    intakeChnlModel: number;
    stepUpDuration: number;
    intakeMktModel: number;
    intakeReqPlg: number;
    intakeTecode: number;
    intakeTgtaud: number;
    intakeTirequirement: number;
}

//Intake Response InterFace
export interface IntakeFormResp {
    intakeFormId: string;
    addUptierPaths: string;
    description: string;
    durationMonths: string;
    instltnIncFlg: string;
    instltnPricing: string;
    prodMustExc: string;
    prodMustInc: string;
    prodMustInstlExc: string;
    prodMustInstlInc: string;
    prodMustRetainExc: string;
    prodMustRetainInc: string;
    products: string;
    projectName: string;
    reqstdExpireDate: string;
    reqstdStartDate: string;
    reqstorEmail: string;
    reqstorName: string;
    stepupAmount: string;
    intakeChnlModel: IntakeChnlModel[];
	intakeDurtnModel: IntakeDurtnMasterModel[];
	intakeMktModel: IntakeMktMasterModel[];
	intakeReqPlgModel: IntakeReqPlgMasterModel[];
	intakeTecodeModel: IntakeTecodeMasterModel[];
	intakeTgtaudModel: IntakeTgtaudMasterModel[];
	intakeTireqModel: IntakeTireqMasterModel[];
}

export interface IntakeChnlModel {
    chnlId: number;
    chnlName: string;
}

export interface IntakeDurtnMasterModel {
    durtnId: number;
    duration: string;
}

export interface IntakeMktMasterModel {
    mktId: number;
    mktName: string;
}

export interface IntakeReqPlgMasterModel {
    reqId: number;
    plgFlag: string;
}

export interface IntakeTecodeMasterModel {
    tecode: number;
    tecodeName: string;
}

export interface IntakeTgtaudMasterModel {
    tgtId: number;
    tgtName: string;
}

export interface IntakeTireqMasterModel {
    tierId: number;
    tierName: string;
}


export interface Markets {
    projSiteMapId: number;
    projectCode: string;
    siteId: number;
    enableFlag: string;
}

export interface MapProjectTypes {
    mapProjectTypeId: number;
    mapProjectTypeName: string;
}


export interface MapMarketList {
    mapMarketId: string;
    mapMarketName: string;
}


//MarketingOffers-Request interface
export interface MarketingOffersRequest {
    projectCode: string;
    offerId: number;
    offerType: string;
    offerDescription: string;
    offerStartDate: string;
    offerEndDate: string;
    psyTypeModelList: PsyTypeModelList[]
    price: string;
    priceSpec: string;
    discountValue: string;
    discountTypeId: number;
    discountRule: string;
    psuType: string;
	bundleType: string;
}


export interface PsyTypeModelList {
    psuTypeId: number;
    psuName: string;
    description: string;
}

//MarketingOffers-Response interface
export interface MarketingOfferResponse {
    actionResult: string;
    actionStatus: string;
    projectMasterModel: ProjectMasterModel;
    mrktingOfferModel: AddMrktingOfferModel[];
    discTypeMasterModel: DiscTypeMasterModel[];
    mktOffrDiscountMasterModel: MktOffrDiscountMasterModel[];
    psuTypeDetailModelMap: Map<string,PsuTypeDetailModelMap[]>;
}


export interface ProjectMasterModel {
    projectCode: string;
    projectType: string;
    projectTypeName: string;
    projectDesc: string;
    projectStartDt: string;
    projectEndDt: string;
    market: number[];
    status: string;
    statusName: string;
    assignedTo: string;
    processId: number;
    siteMap: Map<string, string>;
}

export interface AddMrktingOfferModel {
    moId: string;
    projectCode: string;
    createdBy: string;
    createdDate: string;
    description: string;
    discValue: string;
    endDate: string;
    modifiedDate: string;
    offerType: string;
    price: number;
    priceSpec: string;
    startDate: string;
	discountTypeId: number;
	discountRule: string;
	psuType: string;
	bundleType: string;
    supplementaryRule: string;
    moProductDataModel: MoProductDataModel[];
    currencyId: string;
    bundleMasterModel: BundleMasterModel;
    currencyMasterModel: CurrencyMasterModel;
    mktOffrDiscountMasterModel: MktOffrDiscountMasterModel;
    projectMasterModel: ProjectMasterModel;
}

export interface MoProductDataModel {
    prodDataId: string;
    prodDetail: string;
    psuType: string;
    mrktingOfferTxnDetModel: Object[];
    psuTypeMasterModel: PsuTypeMasterModel;
}


// export interface MrktingOfferTxnDetModel {

// }

// export interface PsuTypeMasterModel {

// }

export interface BundleMasterModel {
    bndlId: number;
    bndlName: string;
}

export interface CurrencyMasterModel {
    currencyId: number;
    currencyName: string;
}

// export interface MarketModel {

// }

// export interface SiteMap {

// }

export interface DiscTypeMasterModel {
    discTypeId: number;
    discTypeName: string;
}
export interface MktOffrDiscountMasterModel {
    discTypeId: string;
    discTypeName: string;

}

export interface PsuTypeDetailModelMap {
    psuTypeId: string;
    psuName: string;
    description: string;

}

// Add New Project Request Interface
export interface AddUpdateProjectRequest {
    projectCode: string;
    projectType: string;
    projectStartDt: string;
    projectEndDt: string;
    market: number[];
    description: string;
    intakeFormReq: IntakeFormReq[];
}

// Add new Project Response Interface
export interface AddUpdateProjectResponse {
    actionResult: string;
    actionStatus: string;
    projectCode: string;
    projectType: string;
    projectStatus: string;
    projectStartDt: string;
    projectEndDt: string;
    description: string;
    market: Markets[];
    status: string;
    assignedTo: string;
    sites: string[];
    mapProjectTypes: Map<string, string>;
    mapMarketList: Map<string, string>;
    intakeFormResp: IntakeFormResp;
}

// // EditProj-Request Interface start 

// export interface EditProjRequest {
//     projectCode: string;
//     projectType: string;
//     projectStartDt: string;
//     projectEndDt: string;
//     market: [number];
//     description: string;
//     intakeFormReq: IntakeFormReq[];
// }

// // EditProj-Response Interface start 
// export interface EditProjResponse {
//     actionResult: string;
//     actionStatus: string;
//     projectCode: string;
//     projectType: string;
//     projectStatus: string;
//     projectStartDt: string;
//     projectEndDt: string;
//     description: string;
//     market: Markets[];
//     status: string;
//     assignedTo: string;
//     sites: [string];
//     mapProjectTypes: object;
//     mapMarketList: object;
//     intakeFormResp: IntakeFormResp[];

// }

// // modifyMarketingOffer-Request  Interface started from  here 
// export interface ModifyMarketingOfferRequest {
//     projectCode: string;
//     offerId: string;
//     offerType: string;
//     offerDescription: string;
//     offerStartDate: string;
//     offerEndDate: string;
//     psuTypeDetailModelMap: PsuTypeDetailModelMap[];
//     price: string;
//     priceSpec: string;
//     discountValue: string;
//     discountTypeId: string;
//     discountRule: string;
//     psuType: string;

// }

// // modifyMarketingOffer-Response Interface Started from here 
// export interface ModifyMarketingOfferResponse {
//     actionResult: string;
//     actionStatus: string;
//     projectMasterModel: ProjectMasterModel[];
//     mrktingOfferModel: MrktingOfferModel[];
//     discTypeMasterModel: DiscTypeMasterModel[];
//     mktOffrDiscountMasterModel: MktOffrDiscountMasterModel[]
//     psuTypeDetailModelMap: Map<string, PsuTypeDetailModelMap[]>;

// }

// export interface MrktingOfferModel {
//     moId: string;
//     createdBy: string;
//     createdDate: string;
//     description: string;
//     discValue: string;
//     endDate: string;
//     modifiedDate: string;
//     offerType: string;
//     prices: number;
//     priceSpec: string;
//     startDate: string;
//     supplementaryRule: string;
//     moProductDataModel: MoProductDataModel[];
//     bundleMasterModel: BundleMasterModel[];
//     currencyMasterModel: CurrencyMasterModel[];
//     mktOffrDiscountMasterModel: MktOffrDiscountMasterModels[];
//     projectMasterModel: ProjectMasterModel[];

// }

export interface PsuTypeMasterModel {
    psuTypeId: string;
    psuName: string;
    description: string;
}

// psuTypes-Response  Interface started from here 

export interface PsuTypesResponse {
    actionResult: string;
    actionStatus: string;
    psuTypeId: string;
    psuName: string;
    description: string;
    psuTypes: PsuTypes[];
}


export interface PsuTypes {
    Data: string;
    Phone: string;
    Video: string;
    Homelife: string;
}

export interface ProjectTypeModel {
    projectTypeId: string;
    projectTypeName: string;
}

//Modify Marketing Offer interface
export interface ModifyMarketingOffer {
    actionResult: string;
    actionStatus: string;
    projectCode: string;
    projectMasterModel: ProjectMasterModel;
    mrktingOfferModel: ViewAddMrktingOfferModel[];
}

export interface GetMarketingOffer {
    offerCode: string;
    offerType: string;
    bundleType: string;
    offerStartDate: string;
    offerEndDate: string;
    offerDescription: string;
    dataProductType: string;
    phoneProductType:string;
    videoProductType:string;
    homelifeProductType:string;
    price: string;
    priceSpec: string;
    discountType: string;
    discountValue: string;
    discountDuration: string;
    discountRule: string;
  }


// viewMarketingProj-request interface started from here 

export interface ViewMarketingProjRequest {
    projectCode: string;

}

// viewMarketingProj-response  intereface started from here 

export interface ViewMarketingProjResponse {
    actionResult: string;
    actionStatus: string;
    projectCode: string;
    projectMasterModel: ProjectMasterModel[];
    mrktingOfferModel: string;
    mrktingOfferModelMap: Map<string, ViewAddMrktingOfferModel[]>;
}

export interface ViewAddMrktingOfferModel {
    moId: string;
    projectCode: string;
    createdBy: string;
    createdDate: number;
    description: string;
    discValue: string;
    endDate: string;
    modifiedDate: number;
    offerType: string;
    price: number;
    priceSpec: string;
    startDate: string;
	discountTypeId: number;
	discountRule: string;
	psuType: string;
	bundleType: string;
    moProductDataModel: MoProductDataModel[];
    currencyId: string;
    bundleMasterModel: BundleMasterModel;
    currencyMasterModel: CurrencyMasterModel;
    mktOffrDiscountMasterModel: MktOffrDiscountMasterModel;
}

// export interface ProjectMasterModels {
//     projectCode: string;
//     projectType: string;
//     projectTypeName: string;
//     projectDesc: string;
//     projectStartDt: string;
//     projectEndDt: string;
//     market: [number],
//     status: string;
//     statusName: string;
//     assignedTo: string;
//     processId: number;
//     siteMap: object;
// }

// export interface MrktingOfferModels {

//     moId: string;
//     createdBy: string;
//     createdDate: string;
//     description: string;
//     discValue: string;
//     endDate: string;
//     modifiedDate: string;
//     offerType: string;
//     price: number;
//     priceSpec: string;
//     startDate: string;
//     supplementaryRule: string;
//     moProductDataModel: MoProductDataModels[];
//     bundleMasterModel: BundleMasterModels[];
//     currencyMasterModel: CurrencyMasterModels[];
//     mktOffrDiscountMasterModel: MktOffrDiscountMasterModels[];
//     projectMasterModel: ProjectMasterModels[];


// }

// export interface MoProductDataModels {
//     prodDataId: string;
//     prodDetail: string;
//     psuType: string;
//     mrktingOfferTxnDetModel: Object[];
//     psuTypeMasterModel: PsuTypeMasterModels[];

// }

// // export interface MrktingOfferTxnDetModels {

// // }

// export interface PsuTypeMasterModels {
//     psuTypeId: string;
//     psuName: string;
//     description: string;

// }

// export interface BundleMasterModels {
//     bndlId: string;
//     bndlName: string;
// }

// export interface CurrencyMasterModels {
//     currencyId: string;
//     currencyName: string;
// }

// export interface MktOffrDiscountMasterModels {
//     discTypeId: string;
//     discTypeName: string;
// }

// export interface ProjectMasterModels {
//     projectCode: string;
//     projectType: string;
//     projectTypeName: string;
//     projectDesc: string;
//     projectStartDt: string;
//     projectEndDt: string;
//     market: [number];
//     status: string;
//     statusName: string;
//     assignedTo: string;
//     processIds: string;
//     siteMaps: object;
// }


// viewProject-Request  Interface started from here 

export interface ViewProjectRequest {
    projectCode: string;
}

// ViewProject-Response Interface started from  here 

export interface ViewProjectResponse {
    projectCode: string;
    projectMasterModel: ProjectMasterModel[];
    mrktingOfferModel: AddMrktingOfferModel[];
}

// export interface ProjectMasterModelData {
//     projectCode: string;
//     projectType: string;
//     projectTypeName: string;
//     projectDesc: string;
//     projectStartDt: string;
//     projectEndDt: string;
//     market: object;
//     status: string;
//     statusName: string;
//     assignedTo: string;
//     processId: string;
//     siteMap: object;
// }

// export interface MrktingOfferModelData {
//     moId: string;
//     createdBy: string;
//     createdDate: string;
//     description: string;
//     discValue: string;
//     endDate: string;
//     modifiedDate: string;
//     offerType: string;
//     price: string;
//     priceSpec: string;
//     startDate: string;
//     supplementaryRule: string;
//     moProductDataModel: MoProductDataModelData[];
//     bundleMasterModel: BundleMasterModelData[];
//     currencyMasterModel: CurrencyMasterModelData[];
//     mktOffrDiscountMasterModel: MktOffrDiscountMasterModelData[];
//     projectMasterModel: ProjectMasterModelDatas[];

// }

// export interface MoProductDataModelData {
//     prodDataId: string;
//     prodDetail: string;
//     psuType: string;
//     mrktingOfferTxnDetModel: Object[]
// }

// // export interface MrktingOfferTxnDetModelData {

// // }

// export interface BundleMasterModelData {
//     bndlId: string;
//     bndlName: string;
// }

// export interface CurrencyMasterModelData {
//     currencyId: string;
//     currencyName: string;
// }

// export interface MktOffrDiscountMasterModelData {
//     discTypeId: string;
//     discTypeName: string;
// }

// export interface ProjectMasterModelDatas {
//     projectCode: string;
//     projectType: string;
//     projectTypeName: string;
//     projectDesc: string;
//     projectStartDt: string;
//     projectEndDt: string;
//     market: object;
//     status: string;
//     statusName: string;
//     assignedTo: string;
//     processId: string;
//     siteMap: object
// }



// defaultMarketingData-Response  Interface started from Here 

export interface DefaultMarketingDataResponse {
    actionResult: string;
    actionStatus: string;
    projectMasterModel: ProjectMasterDefaultModel[];
    mrktingOfferModel: MrktingOfferDefaultModel[];
    discTypeMasterModel: DiscDefaultTypeMasterModel[];
    mktOffrDiscountMasterModel: MktOffrDefaultDiscountMasterModel[];
    psuTypeDetailModelMap: PsuTypeDefaultDetailModelMap[];


}

export interface ProjectMasterDefaultModel {
    projectCode: string;
    projectType: string;
    projectTypeName: string;
    projectDesc: string;
    projectStartDt: string;
    projectEndDt: string;
    market: [number];
    status: string;
    statusName: string;
    assignedTo: string;
    processId: number;
    siteMap: object;
}

export interface MrktingOfferDefaultModel {
    moId: string;
    createdBy: string;
    createdDate: string;
    description: string;
    discValue: string;
    endDate: string;
    modifiedDate: string;
    offerType: string;
    price: number;
    priceSpec: string;
    startDate: string;
    supplementaryRule: string;
    moProductDataModel: MoProductDataDefaultModel[];
    bundleMasterModel: BundleDefaultMasterModel[];
    currencyMasterModel: CurrencyDefaultMasterModel[];
    mktOffrDiscountMasterModel: MktOffrDiscountDefaultMasterModel[];
    projectMasterModel: ProjectDefaultMasterModel[];
}

export interface MoProductDataDefaultModel {
    prodDataId: string;
    prodDetail: string;
    psuType: string;
    mrktingOfferTxnDetModel: Object;
    psuTypeMasterModel: PSUTypeDefaultMasterModel[];

}

// export interface MrktingOfferDefaultTxnDetModel {

// }

export interface PSUTypeDefaultMasterModel {
    psuTypeId: string;
    psuName: string;
    description: string;
}

export interface BundleDefaultMasterModel {
    bndlId: string;
    bndlName: string;
}

export interface CurrencyDefaultMasterModel {
    currencyId: string;
    currencyName: string;
}

export interface MktOffrDiscountDefaultMasterModel {
    discTypeId: string;
    discTypeName: string;
}

export interface ProjectDefaultMasterModel {
    projectCode: string;
    projectType: string;
    projectTypeName: string;
    projectDesc: string;
    projectStartDt: string;
    projectEndDt: string;
    market: [number];
    status: string;
    statusName: string;
    assignedTo: string;
    processId: string;
    siteMap: object;
}

export interface DiscDefaultTypeMasterModel {
    discTypeId: number;
    discTypeName: string;
}

export interface MktOffrDefaultDiscountMasterModel {
    discTypeId: string;
    discTypeName: string;
}

export interface PsuTypeDefaultDetailModelMap {
    psuTypeId: number;
    psuName: string;
    description: string;
}



// // deleteMarketingoffer-Response  Interface started from here 

// export interface DeleteMarketingofferResponse {
//     actionResult: string;
//     actionStatus: string;
//     projectCode: string;
//     projectMasterModel: ProjectDeleteMasterModel[];
//     mrktingOfferModel: MrktingDeleteOfferModel[];
// }

// export interface ProjectDeleteMasterModel {
//     projectCode: string;
//     projectType: string;
//     projectTypeName: string;
//     projectDesc: string;
//     projectStartDt: string;
//     projectEndDt: string;
//     market: [number];
//     status: string;
//     statusName: string;
//     assignedTo: string;
//     processId: number;
//     siteMap: object;
// }

// export interface MrktingDeleteOfferModel {
//     moId: string;
//     createdBy: string;
//     createdDate: string;
//     description: string;
//     discValue: string;
//     endDate: string;
//     modifiedDate: string;
//     offerType: string;
//     price: number;
//     priceSpec: string;
//     startDate: string;
//     supplementaryRule: string;
//     moProductDataModel: MoProductDeleteDataModel[];
//     bundleMasterModel: BundleDeleteMasterModel[];
//     currencyMasterModel: CurrencyDeleteMasterModel[];
//     mktOffrDiscountMasterModel: MktOffrDeleteDiscountMasterModel[];
//     projectMasterModel: ProjectMasterDeleteModel[];
// }

// export interface MoProductDeleteDataModel {
//     "prodDataId": string;
//     "prodDetail": string;
//     "psuType": string;
//     mrktingOfferTxnDetModel: Object[];
//     psuTypeMasterModel: PsuTypeDeleteMasterModel[];


// }

// // export interface MrktingDeleteOfferTxnDetModel {

// // }

// export interface PsuTypeDeleteMasterModel {
//     psuTypeId: string;
//     psuName: string;
//     description: string;
// }

// export interface BundleDeleteMasterModel {
//     bndlId: string;
//     bndlName: string;
// }

// export interface CurrencyDeleteMasterModel {
//     currencyId: string;
//     currencyName: string;
// }

// export interface MktOffrDeleteDiscountMasterModel {
//     discTypeId: string;
//     discTypeName: string;
// }

// export interface ProjectMasterDeleteModel {
//     projectCode: string;
//     projectType: string;
//     projectTypeName: string;
//     projectDesc: string
//     projectStartDt: string;
//     projectEndDt: string;
//     market: [number];
//     status: string;
//     statusName: string;
//     assignedTo: string;
//     processId: string;
//     siteMap: object

// }


// Add_Project_Master_Data  Interface started from Here 

export interface AddProjectMasterData {
    projectCode: string;
    projectStartDt: string;
    projectEndDt: string;
    description: string;
    mapProjectTypes: object;
    mapMarketList: object;
    intakeFormResp: IntakeFormMasterDataResp[];
}

export interface IntakeFormMasterDataResp {
    intakeFormId: string;
    addUptierPaths: string;
    description: string;
    durationMonths: string;
    instltnIncFlg: string;
    instltnPricing: string;
    prodMustExc: string;
    prodMustInc: string;
    prodMustInstlExc: string;
    prodMustInstlInc: string;
    prodMustRetainExc: string;
    products: string;
    projectName: string;
    reqstorEmail: string;
    reqstorName: string;
    stepupAmount: string;
    intakeChnlModel: IntakeChnlMasterDataModel[];
    intakeDurtnModel: IntakeDurtnMasterDataModel[];
    intakeMktModel: IntakeMktDataMasterModel[];
    intakeReqPlgModel: IntakeReqPlgDataMasterModel[];
    intakeTecodeModel: IntakeTecodeDataMasterModel[];
    intakeTgtaudModel: IntakeTgtaudDataMasterModel[];
    intakeTireqModel: IntakeTireqDataMasterModel[];
}

export interface IntakeChnlMasterDataModel {
    chnlId: number;
    chnlName: string;
}

export interface IntakeDurtnMasterDataModel {
    durtnId: number;
    duration: string;
}

export interface IntakeMktDataMasterModel {
    mktId: number;
    mktName: string;
}

export interface IntakeReqPlgDataMasterModel {
    reqId: number;
    plgFlag: string;
}

export interface IntakeTecodeDataMasterModel {
    tecode: number;
    tecodeName: string;
}

export interface IntakeTgtaudDataMasterModel {
    tgtId: number;
    tgtName: string;
}

export interface IntakeTireqDataMasterModel {
    tierId: number;
    tierName: string;
}


// Fetch_All_Projects  Interface started from Here 
export interface FetchAllProjects {
    projectCode: string;
    projectType: string;
    projectStatus: string;
    projectStartDt: string;
    projectEndDt: string;
    description: string;
    market: Markets[];
    status: string;
    assignedTo: string;
    sites: string[];
    mapProjectTypes: Map<string, string>;
    mapMarketList: Map<string, string>;
    intakeFormResp: IntakeFormResp;
}

export interface SubmitProjectInfo{
    projectCode: string;
}

