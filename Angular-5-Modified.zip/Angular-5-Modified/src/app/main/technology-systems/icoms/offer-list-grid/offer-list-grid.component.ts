import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-offer-list-grid',
  templateUrl: './offer-list-grid.component.html'
})
export class OfferListGridComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
