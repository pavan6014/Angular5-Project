import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-icoms',
  templateUrl: './icoms.component.html'
})
export class IcomsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
