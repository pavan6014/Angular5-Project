import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-project-detail-info',
  templateUrl: './project-detail-info.component.html'
})
export class ProjectDetailInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
