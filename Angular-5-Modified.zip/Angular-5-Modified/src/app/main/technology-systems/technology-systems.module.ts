import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TechnologySystemsRoutingModule } from './technology-systems-routing.module';
import { UatComponent } from './uat/uat.component';
import { UatUsersComponent } from './uat/uat-users/uat-users.component';
import { SearchOfferComponent } from './uat/uat-users/search-offer/search-offer.component';
import { OfferGridComponent } from './uat/uat-users/offer-grid/offer-grid.component';
import { IcomsComponent } from './icoms/icoms.component';
import { OfferListGridComponent } from './icoms/offer-list-grid/offer-list-grid.component';
import { OfferDetailInfoComponent } from './icoms/offer-detail-info/offer-detail-info.component';
import { SearchProjectComponent } from './omc/search-project/search-project.component';
import { ProjectListGridComponent } from './omc/project-list-grid/project-list-grid.component';
import { ProjectDetailInfoComponent } from './omc/project-detail-info/project-detail-info.component';
import { PinpointComponent } from './pinpoint/pinpoint.component';
import { EcomComponent } from './ecom/ecom.component';
import { OmcComponent } from './omc/omc.component';

@NgModule({
    imports: [
        CommonModule,
        TechnologySystemsRoutingModule
    ],
    declarations: [
        UatComponent,
        UatUsersComponent,
        SearchOfferComponent,
        IcomsComponent,
        OfferGridComponent,
        OfferListGridComponent,
        OfferDetailInfoComponent,
        SearchProjectComponent,
        ProjectListGridComponent,
        ProjectDetailInfoComponent,
        PinpointComponent,
        EcomComponent,
        OmcComponent
    ]
})
export class TechnologySystemsModule {}
