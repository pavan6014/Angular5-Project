import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { SearchUserRequest } from '../search-user.interface';

@Component({
  selector: 'plm-search-user-criteria',
  templateUrl: './search-user-criteria.component.html'
})
export class SearchUserCriteriaComponent implements OnInit {
  @Input() searchInFilter:String[];
  @Output() searchUser: EventEmitter<SearchUserRequest> = new EventEmitter<SearchUserRequest>();
  @ViewChild('searchUserForm') public searchUserForm: NgForm;
  private searchInput: string;
  private searchIn: string;

  constructor() {
    this.searchInput = '';
    this.searchIn = '';
  }

  ngOnInit() {
  }

  searchUserByCriteria(){
      const reqObj = {
        'searchcriteria': this.searchUserForm.value.searchInput,
        'criteriatype': this.searchUserForm.value.searchIn
      }
      this.searchUserForm.reset();
      this.searchUser.emit(reqObj);
  }

}
