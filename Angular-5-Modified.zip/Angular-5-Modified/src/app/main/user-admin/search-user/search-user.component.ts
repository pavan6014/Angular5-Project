import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { SearchUserService } from './search-user.service';
import { BreadCrumb } from '../../../shared/services/bread-crumb';
import { SearchUserRequest } from './search-user.interface';
import { SearchUserCriteriaComponent } from './search-user-criteria/search-user-criteria.component';
import { UserListComponent } from './user-list/user-list.component';
import { SearchUserModel, SearchUserResponse } from './search-user.interface';
import { UtilitiesService } from '../../../shared/services/utilities.service';

@Component({
    selector: 'plm-search-user',
    templateUrl: './search-user.component.html',
    providers: [SearchUserService, UtilitiesService]
})
export class SearchUserComponent implements OnInit {
    private breadCrumbs: BreadCrumb[];
    private searchInFilter: string[];
    private formDataAvailable: boolean;
    private statusUpdated: boolean;
    private invalidEmail: boolean;
    private noUserFound: boolean;
    private searchUserCriteria: SearchUserRequest;
    private userList: SearchUserResponse;

    constructor(private searchUserService:SearchUserService, private utilitiesService: UtilitiesService){
        this.formDataAvailable = false;
        this.statusUpdated = false;
        this.breadCrumbs = this.searchUserService.getBreadCrumbs();
        this.getSearchCriteria();
    }
    
    ngOnInit() {
    }

    getSearchCriteria(){
        this.searchUserService.getSearchCriteria()
            .subscribe(
                data => {
                    this.searchInFilter = data.searchCriteria;
                    this.formDataAvailable = true;
                },
                error => {
                    console.log("Error :: " + error)
                }
            );
    }

    onsearchUser(searchCriteria: SearchUserRequest){
        this.statusUpdated = false;
        this.invalidEmail = false;
        this.noUserFound = false;
        if ((searchCriteria.criteriatype === 'EMAIL') && (!this.utilitiesService.isEmailAddress(searchCriteria.searchcriteria))){
            this.invalidEmail = true;
            this.userList = {
                'actionResult': null,
                'actionStatus': null,
                'searchUserModel': []
            }
            return false;
        }
        this.searchUserService.getUserList(searchCriteria)
            .subscribe(
                data => {
                    this.userList = data;
                    this.formDataAvailable = true;
                },
                error => {
                    console.log("Error :: " + error)
                }
            );
    }

    onStatusUpdate(statusUpdated: boolean): void{
       if (statusUpdated) {
           this.statusUpdated = true;
       } else {
           this.statusUpdated = false;
       }
    }
};

