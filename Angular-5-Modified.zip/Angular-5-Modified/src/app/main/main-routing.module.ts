import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainComponent } from './main.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGuard } from './../shared';

const routes: Routes = [
    {
        path: '',
        component: MainComponent,
        children: [
            { path: '', component: DashboardComponent },
            { path: 'dashboard', component: DashboardComponent },
            {
                path: 'plm-work-flow/requestor',
                loadChildren: './requestor/requestor.module#RequestorModule', 
                canActivate: [AuthGuard]
            },
            { 
                path: 'plm-work-flow/configurator', 
                loadChildren: './configurator/configurator.module#ConfiguratorModule', 
                canActivate: [AuthGuard] 
            },
            { 
                path: 'plm-work-flow/distributor', 
                loadChildren: './distributor/distributor.module#DistributorModule', 
                canActivate: [AuthGuard] 
            },
            { 
                path: 'plm-work-flow/technology-systems', 
                loadChildren: './technology-systems/technology-systems.module#TechnologySystemsModule', 
                canActivate: [AuthGuard] 
            },
            { 
                path: 'report', 
                loadChildren: './report/report.module#ReportModule', 
                canActivate: [AuthGuard] 
            },
            { 
                path: 'user-admin', 
                loadChildren: './user-admin/user-admin.module#UserAdminModule', 
                canActivate: [AuthGuard] 
            },
            { 
                path: 'business-catalog', 
                loadChildren: './business-catalog/business-catalog.module#BusinessCatalogModule', 
                canActivate: [AuthGuard] 
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class MainRoutingModule { }
