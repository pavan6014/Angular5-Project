import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-discounts',
  templateUrl: './discounts.component.html',
  styleUrls: ['./discounts.component.css']
})
export class DiscountsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
