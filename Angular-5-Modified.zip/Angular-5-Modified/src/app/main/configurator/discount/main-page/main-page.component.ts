import { Component, OnInit, Input, Output } from '@angular/core';
import { DiscountFormDropDown, GetMainPageDataResponse, GetDisMapMainPage  } from '../../../configurator/discount/discount-interface';
import { DiscountService } from '../../../configurator/discount/discount.service';

@Component({
  selector: 'plm-main-page',
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.css']
})
export class MainPageComponent implements OnInit {

  @Input() discountFormDropDown: DiscountFormDropDown;
  @Input() disMapMainPage: GetDisMapMainPage;

  constructor() { }

  ngOnInit() {
  }

}
