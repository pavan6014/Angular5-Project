import { Component, OnInit, Input, Output } from '@angular/core';
import { GetCampaignCodePricingMethod,GetCampaignCodePricingMethodResponse  } from '../../../configurator/discount/discount-interface';

@Component({
  selector: 'plm-campaign-code-creation-pricing-method',
  templateUrl: './campaign-code-creation-pricing-method.component.html',
  styleUrls: ['./campaign-code-creation-pricing-method.component.css']
})
export class CampaignCodeCreationPricingMethodComponent implements OnInit {

  @Input() campaignCodeMethod : GetCampaignCodePricingMethod;
  constructor() { }

  ngOnInit() {
  }

}
