import { Component, OnInit, Input, Output } from '@angular/core';
import { DiscountFormDropDown,GetOSCARResponse, DiscMapOscar  } from '../../../configurator/discount/discount-interface';
import { DiscountService } from '../../../configurator/discount/discount.service';

@Component({
  selector: 'plm-oscar',
  templateUrl: './oscar.component.html',
  styleUrls: ['./oscar.component.css']
})
export class OscarComponent implements OnInit {

  @Input() discountFormDropDown: DiscountFormDropDown;
  @Input() discMapOscar: DiscMapOscar;

  constructor() { }

  ngOnInit() {
  }

}
