import { Component, OnInit, Output, Input, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import {
  GetDiscriptionBuilder,
  GetDiscountIcomsStatus,
  IcomsStatusModel,
  DiscountGift,
  DiscMapPreRequisite,
  DiscMapOscar,
  GetDisMapMainPage,
  GetDiscMapOnline,
  GetMappingTable,
  DiscountFormMasterData,
  DiscountFormDropDown,
  TeCode,
  SubmitDiscountInfo
} from '../discount/discount-interface';
import { DiscountService } from '../discount/discount.service';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
@Component({
  selector: 'plm-discount',
  templateUrl: './discount.component.html',
  providers: [DiscountService]
})
export class DiscountComponent implements OnInit {
  private discountsDiscriptionBuilder: GetDiscriptionBuilder;
  private discountIcomsForms: GetDiscountIcomsStatus;
  private DisountsFormsData: string;
  private discountGift: DiscountGift;
  private discMapPreRequisite: DiscMapPreRequisite;
  private discMapOscar: DiscMapOscar;
  private disMapMainPage: GetDisMapMainPage;
  private discMapOnline: GetDiscMapOnline;
  private masterData: DiscountFormMasterData;
  private teData: TeCode;
  private discountFormDropDown: DiscountFormDropDown;
  private mappingTable: GetMappingTable;


  constructor(private icomsStatusService: DiscountService, private router: Router, public dialog: MatDialog) {
    this.getIcomsStatusData();
    this.getDiscountFormData();
    this.initializeDiscountFormDropDown();
  }

   openDialog(): void {
    let dialogRef = this.dialog.open(DialogOverviewExampleDialogs, {
      width: 'auto'
    });

    dialogRef.afterClosed().subscribe(result => {
      //console.log('The dialog was closed');
    });
  }

  ngOnInit() {
  }

  

  getIcomsStatusData() {
    this.icomsStatusService.getIcomsStatus()
      .subscribe(
      data => {
        this.masterData = data;
        console.log("Master Data", this.masterData);
        this.teData = data.teCodeResponse.teCodes;
        console.log("teData", this.teData);
        this.populateFormFieldValues();
      },
      error => {
        //console.log("Error :: " + error)
      }
      );
  }


  populateFormFieldValues() {
    for (let i = 0; i < this.masterData.commonData.length; i++) {
      const currentMasterData = this.masterData.commonData[i];
      this.discountFormDropDown[currentMasterData.name] = currentMasterData.records;
    }
    console.log("xxxx", this.discountFormDropDown);
  }


  initializeDiscountFormDropDown() {
    this.discountFormDropDown = {
    'VIDEO_TIERS': [],
    'PHONE_TIERS': [],
    'HOMELIFE_TIERS': [],
    'ANCILLARY': [],
    'EQUIPMENT': [],
    'INSTALL': [],
    'GIFT_VALIDATION_STATUS': [],
    'OFFER_FAMILY': [],
    'FINANCE_BUCKET_CD': [],
    'PROGRAM_NM': [],
    'CUSTOMER_TARGET': [],
    'CAMPAIGN_TYPE': [],
    'CAMPAIGN_SUBTYPE': [],
    'SA_TYPE_REQUIRED': [],
    'INSTALL_INCLUDED': [],
    'PRODUCT': [],
    'OSCAR_STATUS': [],
    'FINANCE_BUCKET_PROG_CD': [],
    'SPCL_HANDLING_INSTRUCTIONS': [],
    'MARGIN_BUCKET': [],
    'MARKETING_ID_DESC': [],
    'MP_NEW_EXISTING': [],
    'MP_OFFER_PRODUCT': [],
    'MP_OFFER_TYPE': [],
    'MP_TARGETED_AUDIENCE': [],
    'MP_INSTALLATION_TPR': [],
    'ONLINE_STATUS': [],
    'PRICING_CATEGORY': [],
    'PRESENTATION_CODE': [],
    'MARKETING_ID': [],
    'ICOMS_STATUS': [],
    'IT_PEER_REVIWED': [],
    'IT_ASSIGNED_TO': [],
    'DISCOUNT_TYPES': [],
    'DATA_TIRES': [],
    'MIN_VIDEO_TIER': [],
    'MIN_DATA_TIER': [],
    'MIN_PHONE_TIER': [],
    'MIN_HOME_LIFE_TIER': [],
    }
  }

  getDiscountFormData() {
    this.icomsStatusService.getDiscountFormData()
      .subscribe(
      data => {
        this.DisountsFormsData = data;
        console.log(" Forms Data", this.DisountsFormsData);
        this.discountsDiscriptionBuilder = data.discount.discMapDescrBuild;
        console.log("Discription Builder Forms Data", this.discountsDiscriptionBuilder);
        this.discountIcomsForms = data.discount.discountIcoms;
        console.log("Icoms Forms Data", this.discountIcomsForms);
        this.discountGift = data.discount.discountGift;
        console.log("Gift Card Data", this.discountGift);
        this.discMapPreRequisite = data.discount.discMapPreRequisite;
        console.log("discMapPreRequisite", this.discMapPreRequisite);
        this.discMapOscar = data.discount.discMapOscar;
        console.log("Oscar Data", this.discMapOscar);
        this.disMapMainPage = data.discount.disMapMainPage;
        console.log("Main Page Form", this.disMapMainPage);
        this.discMapOnline = data.discount.discMapOnline;
        console.log("Online Form", this.discMapOnline);
        this.mappingTable = data.discount.discMappingEntity;
        console.log("Mapping Table", this.mappingTable);

      },
      error => {
        console.log("Error :: " + error)
      }
      );

  }

  submitProject(){

    let reqObj: SubmitDiscountInfo;
    reqObj =  {
    'discriptionBuilder': this.discountsDiscriptionBuilder,
    'discountIcomsStatus': this.discountIcomsForms,
    'discountGift': this.discountGift,
    'discMapPreRequisite': this.discMapPreRequisite,
    'discMapOscar': this.discMapOscar,
    'disMapMainPage': this.disMapMainPage,
    'discMapOnline': this.discMapOnline,
    'mappingTable': this.mappingTable,
    'discountFormDropDown': this.discountFormDropDown,
    'discountFormMasterData': this.masterData
    }
    this.icomsStatusService.submitProject(reqObj).subscribe(
      data => {
        this.openDialog();
      },
      error => {
        //console.log("Error :: " + error)
      }
    );
  }

  returnBack() {
    this.router.navigate(['/plm-work-flow/configurator/offer/project-list']);
  }

}

@Component({
  selector: 'discount-confirmation-dialog',
  templateUrl: '../discount/discount-confirmation-dialog.html'
})
export class DialogOverviewExampleDialogs {

  constructor(
    public dialogRef: MatDialogRef<DialogOverviewExampleDialogs>, private router: Router, 
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onNoClick(): void {
    this.dialogRef.close();
  }

  moveToDashboard(){
    this.dialogRef.close();
    this.router.navigate(['']);
  }

}
