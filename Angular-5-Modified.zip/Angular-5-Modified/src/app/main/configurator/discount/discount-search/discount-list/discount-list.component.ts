import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-discount-list',
  templateUrl: './discount-list.component.html'
})
export class DiscountListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
