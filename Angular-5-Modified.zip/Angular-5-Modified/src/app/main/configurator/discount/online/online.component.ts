import { Component, OnInit, Input, Output } from '@angular/core';
import { DiscountFormDropDown, GetOnlineResponse, GetDiscMapOnline  } from '../../../configurator/discount/discount-interface';
import { DiscountService } from '../../../configurator/discount/discount.service';

@Component({
  selector: 'plm-online',
  templateUrl: './online.component.html',
  styleUrls: ['./online.component.css']
})
export class OnlineComponent implements OnInit {

  @Input() discountFormDropDown: DiscountFormDropDown;
  @Input() discMapOnline : GetDiscMapOnline;

  constructor() { }

  ngOnInit() {
  }

}
