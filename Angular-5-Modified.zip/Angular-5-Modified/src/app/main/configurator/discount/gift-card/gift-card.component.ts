import { Component, OnInit, Input, Output } from '@angular/core';
import { DiscountFormDropDown,GetDiscountGiftCardResponse, DiscountGift  } from '../../../configurator/discount/discount-interface';
import { DiscountService } from '../../../configurator/discount/discount.service';


@Component({
  selector: 'plm-gift-card',
  templateUrl: './gift-card.component.html',
  styleUrls: ['./gift-card.component.css']
})
export class GiftCardComponent implements OnInit {

  @Input() discountFormDropDown: DiscountFormDropDown;
  @Input() discountGift: DiscountGift;

  constructor() { }

  ngOnInit() {
  }

}
