import { Component, OnInit, Output, Input } from '@angular/core';
import { DiscountFormDropDown,GetMappingTableResponse, GetMappingTable  } from '../../../configurator/discount/discount-interface';
import { DiscountService } from '../../../configurator/discount/discount.service';

@Component({
  selector: 'plm-mapping-table',
  templateUrl: './mapping-table.component.html',
  styleUrls: ['./mapping-table.component.css']
})
export class MappingTableComponent implements OnInit {

@Input() discountFormDropDown: DiscountFormDropDown;
@Input() mappingTable: GetMappingTable;


  constructor() { }

  ngOnInit() {
  }

}
