import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IcomsStatusComponent } from './icoms-status.component';

describe('IcomsStatusComponent', () => {
  let component: IcomsStatusComponent;
  let fixture: ComponentFixture<IcomsStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IcomsStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IcomsStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
