import { Component, OnInit,  Output,Input } from '@angular/core';
import { DiscountFormDropDown,GetIcomsStatusResponse, GetDiscountIcomsStatus  } from '../../../configurator/discount/discount-interface';
import { DiscountService } from '../../../configurator/discount/discount.service';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'plm-icoms-status',
  templateUrl: './icoms-status.component.html',
  styleUrls: ['./icoms-status.component.css'],
  providers: [ DiscountService ]
})
export class IcomsStatusComponent implements OnInit {


// @Input() discountsIcoms: GetIcomsStatus;
@Input() discountFormDropDown: DiscountFormDropDown;
@Input() discountIcomsForms: GetDiscountIcomsStatus;

  constructor( private icomsStatusService:DiscountService ) {
           
    }

  ngOnInit() {
  }
}


