import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { AppConfigService } from '../../../shared/services/app-config.service';
import {
  GetDiscriptionBuilder,
  GetDiscountIcomsStatus,
  IcomsStatusModel,
  DiscountGift,
  DiscMapPreRequisite,
  DiscMapOscar,
  GetDisMapMainPage,
  GetDiscMapOnline,
  GetMappingTable,
  DiscountFormMasterData,
  DiscountFormDropDown,
  TeCode,
  SubmitDiscountInfo
} from '../../configurator/discount/discount-interface';


@Injectable()
export class DiscountService {

  constructor(private http: HttpClient, private appConfigService: AppConfigService) { }


  getIcomsStatus(): Observable<any> {
    const getIcomsStatus = this.appConfigService.urlConstants['PLM_DISCOUNT_MASTER_ICOMS_STATUS']
    return this.http
      .get(getIcomsStatus)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }


  submitProject(reqObj): Observable<any> {
    // const getDiscountCreationURL = this.appConfigService.protocol + '://' + this.appConfigService.host + ':' + this.appConfigService.port + '/' + this.appConfigService.urlConstants['PLM_DISCOUNT_ICOMS_STATUS'];
    // return this.http
    //   .post(getDiscountCreationURL, reqObj)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
    const getIcomsStatus = this.appConfigService.urlConstants['PLM_DISCOUNT_MASTER_ICOMS_STATUS']
    return this.http
      .get(getIcomsStatus)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }


  getDiscountFormData(): Observable<any> {
    const getDiscountFormData = this.appConfigService.urlConstants['PLM_DISCOUNT_ICOMS_STATUS']
    return this.http
      .get(getDiscountFormData)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }

  private handleError(error: Response) {
    return Observable.throw(error.statusText);
  }


}
