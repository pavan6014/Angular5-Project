export interface GetIcomsStatus {
    itDiscountChanges: string;
    offerSeries: string;
    itPeerReviewedDate: [string];
    icomsStatus: [string];
    itPeerReviewed: [string];
    itAssignedTo: [string];
}

export interface GetIcomsStatusResponse {
    actionResult: string;
    actionStatus: string;
    GetIcomsStatus: GetIcomsStatus[];
}


export interface GetDiscountBuilder {
    discriptionFormula: string;
    amount: string;
    discountType: string;
    videoTires: [string];
    dataTires: [string];
    phoneTires: [string];
    homeLifeTires: [string];
    ancillaryFeatures: [String];
    equipment: [string];
    install: [string];
}

export interface GetDiscountBuilderResponse {
    actionResult: string;
    actionStatus: string;
    GetDiscountBuilder: GetDiscountBuilder[];
}


export interface GetDiscountGiftCard {
    validationToolStatus: [string];
}

export interface GetDiscountGiftCardResponse {
    actionResult: string;
    actionStatus: string;
    GetDiscountGiftCard: GetDiscountGiftCard[];
}


export interface GetCampaignCodePricingMethod {
    pricingMethod: [string];
}

export interface GetCampaignCodePricingMethodResponse {
    actionResult: string;
    actionStatus: string;
    GetCampaignCodePricingMethod: GetCampaignCodePricingMethod[];
}

export interface GetCampaignCodePricingPreReq {
    serviceCodeCheatSheet: [string];
}

export interface GetCampaignCodePricingPreReqResponse {
    actionResult: string;
    actionStatus: string;
    GetCampaignCodePricingPreReq: GetCampaignCodePricingPreReq[];
}

export interface GetMappingTable {
    offerFamily: [string];
    financeBucketCD: [string];
    custmerTarget: [string];
    campaignType: [string];
    campaignSubType: [string];
    minVideoTier: [string];
    minDataTier: [string];
    minPhoneTier: [string];
    minHomeLifeTier: [string];
    product: [string];
    saTypeRequired: [string];
    programNM: [string];
    installIncluded: [string];


}

export interface GetMappingTableResponse {
    actionResult: string;
    actionStatus: string;
    GetMappingTable: GetMappingTable[];
}



export interface GetOSCAR {
    oscarStatus: [string];
    financeBucketProgCD: [string];
    specialHandlingInstructions: [string];
    marginBucket: [string];
    marketingId: [string];
}

export interface GetOSCARResponse {
    actionResult: string;
    actionStatus: string;
    GetOSCAR: GetOSCAR[];
}



export interface GetMainPageData {
    mpNew: [string];
    mpOfferType: [string];
    mpOfferProduct: [string];
    mpTargetAudience: [string];
    mpInstallation: [string];
}

export interface GetMainPageDataResponse {
    actionResult: string;
    actionStatus: string;
    GetMainPageData: GetMainPageData[];
}

export interface GetOnlineData {
    onlineStatus: [string];
}

export interface GetOnlineResponse {
    actionResult: string;
    actionStatus: string;
    GetOnlineData: GetOnlineData[];
}
//  New Interface started from here 

// Discount Discription Builder Interface 
export interface GetDiscriptionBuilder {
    descrBuildId: string;
    cimalamount: string;
    formula: string;
    dataTierId: string;
    phoneTierId: string;
    hmLifeTierId: string;
    equipmentId: string;
    installId: string;
    videoTierId: string;
    ancillaryFeatureId: string;
    discountId: string;
    discTypeMasterId: string;
}

// ICOMS Interface
export interface GetDiscountIcomsStatus {
    discountMapIcomsId: string;
    assignedTo: string;
    confirmDate: string;
    notes: string;
    offerSeries: string;
    discountChanges: string;
    icomsStatusModel: IcomsStatusModel[];
}

export interface IcomsStatusModel {
    icomsStatusId: string;
    icomsStatusName: string;
}

// Discount Gift Card Interface
export interface DiscountGift {
    discountMapGiftId: string;
    giftcardAmount: string;
    included: string;

}

// PreReq
export interface DiscMapPreRequisite {

    preReqId: string;
    cmpgnCdAIncIfOne: string;
    cmpgnCdDExcIfAny: string;
    cmpgnCdNumOfDays: string;
    cmpgnLongDescr: string;
    curntSrvcAIncIfOne: string;
    curntSrvcBIncIfAll: string;
    curntSrvcCIncIfAtlst: string;
    curntSrvcCOfThese: string;
    curntSrvcDExcIfAny: string;
    curntSrvcEExcIfAll: string;
    curntSrvcFExcIfAtlst: string;
    curntSrvcFOfThese: string;
    icomsAccessList1: string;
    icomsAccessList2: string;
    icomsAccessList3: string;
    icomsAccessList4: string;
    icomsAccessList5: string;
    icomsAccessList6: string;
    instlSrvcAIncIfOne: string;
    instlSrvcBIncIfAll: string;
    instlSrvcCIncIfAtlst: string;
    instlSrvcCOfThese: string;
    instlSrvcDExcIfAny: string;
    instlSrvcEExcIfAll: string;
    instlSrvcFExcIfAtlst: string;
    instlSrvcFOfThese: string;
    mrktIdAIncIfOne: string;
    mrktIdDExcIfAny: string;
    otherInsrct: string;
    plgInstlAIncIfOne: string;
    plgInstlBIncIfAll: string;
    plgInstlDExcIfAny: string;
    plgRetnAIncIfOne: string;
    plgRetnDExcIfAny: string;
    retnSrvcAIncIfOne: string;
    retnSrvcBIncIfAll: string;
    retnSrvcCIncIfAtlst: string;
    retnSrvcCOfThese: string;
    retnSrvcDExcIfAny: string;
    retnSrvcEExcIfAll: string;
    retnSrvcFExcIfAtlst: string;
    retnSrvcFOfThese: string;
    discountId: string;
    preReqIcomsDataBlobs: string;
}

// Oscar
export interface DiscMapOscar {

    oscarId: string;
    adviceFormula: string;
    createdDate: string;
    excldProjectionFlg: string;
    expiredFlg: string;
    globalActive: string;
    mrktId: string;
    proactive: string;
    saRequired: string;
    salesAdvise: string;
    stableDuration: string;
    financeBucketProgCdId: string;
    spclHandlingInstrId: string;
    marginBucketId: string;
    mrktIdDescrId: string;
    statusId: string;
    discountId: string;

}

// Main Page
export interface GetDisMapMainPage {
    mainPageId: string;
    mpMarkets: string;
    mpNotes: string;
    mpOffer: string;
    mpOfferDetailsRestrict: string
    mpPrismCode: string;
    mpSalesChannel: string;
    showMainpageFlg: string;
    mpOfferProductId: string;
    mpTargetedAudienceId: string;
    mpInstallationTprId: string;
    mpNewExistingId: string;
    mpOfferTypeId: string;
    discountId: string;
    mainPageChnlMaps: string;
}


// Online

export interface GetDiscMapOnline {
    discOnlineMapId: string;
    disclaimer: string;
    ecomPromoCode: string;
    savingsSticker: string;
    uptierValues: string;
    onlineStatusId: string;
}

// Mapping Table 

export interface GetMappingTable {
    mappingId: string;
    discountId: string;
    discount: string;
    marketName: string;
    mrc: string;
    numberOfPsu: string;
    primaryDuration: string;
    psuRequired: string;
    retailRate: string;
    secondryDuration: string;
    secondryStepupAmount: string;
    stepupAmount: string;
    financeBucketCdId: string;
    programNmId: string;
    customerTargetId: string;
    campaignTypeId: string;
    campaignSubTypeId: string;
    minDataTierId: string;
    minPhoneTierId: string;
    minHomeLifeTierId: string;
    productId: string;
    saTypeRequiredId: string;
    installIncludeId: string;
    offerFamilyId: string;
    minVideoTierId: string;
}


//  Discount Master Data Interface Started from Here 

export interface DiscountFormMasterData {
    actionResult: string;
    actionStatus: string;
    commonData: commonData[];
}

export interface commonData {
    name: string;
    records: Records[];
}

export interface Records {
    key: number;
    value: string;
}

export interface DiscountFormDropDown {
    VIDEO_TIERS: Records[];
    PHONE_TIERS: Records[];
    HOMELIFE_TIERS: Records[];
    ANCILLARY: Records[];
    EQUIPMENT: Records[];
    INSTALL: Records[];
    GIFT_VALIDATION_STATUS: Records[];
    OFFER_FAMILY: Records[];
    FINANCE_BUCKET_CD: Records[];
    PROGRAM_NM: Records[];
    CUSTOMER_TARGET: Records[];
    CAMPAIGN_TYPE: Records[];
    CAMPAIGN_SUBTYPE: Records[];
    SA_TYPE_REQUIRED: Records[];
    INSTALL_INCLUDED: Records[];
    PRODUCT: Records[];
    OSCAR_STATUS: Records[];
    FINANCE_BUCKET_PROG_CD: Records[];
    SPCL_HANDLING_INSTRUCTIONS: Records[];
    MARGIN_BUCKET: Records[];
    MARKETING_ID_DESC: Records[];
    MP_NEW_EXISTING: Records[];
    MP_OFFER_PRODUCT: Records[];
    MP_OFFER_TYPE: Records[];
    MP_TARGETED_AUDIENCE: Records[];
    MP_INSTALLATION_TPR: Records[];
    ONLINE_STATUS: Records[];
    PRICING_CATEGORY: Records[];
    PRESENTATION_CODE: Records[];
    MARKETING_ID: Records[];
    ICOMS_STATUS: Records[];
    IT_PEER_REVIWED: Records[];
    IT_ASSIGNED_TO: Records[];
    DISCOUNT_TYPES: Records[];
    DATA_TIRES: Records[];
    MIN_VIDEO_TIER: Records[];
    MIN_DATA_TIER: Records[];
    MIN_PHONE_TIER: Records[];
    MIN_HOME_LIFE_TIER: Records[];

}

export interface TeCode {
    actionResult: string;
    actionStatus: string;
    teCodes: TeCodes[];

}

export interface TeCodes {
    teCodeId: string;
    code: string;
    description: string;
    owner: string;
}


export interface SubmitDiscountInfo {
    discriptionBuilder: GetDiscriptionBuilder;
    discountIcomsStatus: GetDiscountIcomsStatus;
    discountGift: DiscountGift;
    discMapPreRequisite: DiscMapPreRequisite;
    discMapOscar: DiscMapOscar;
    disMapMainPage: GetDisMapMainPage;
    discMapOnline: GetDiscMapOnline;
    mappingTable: GetMappingTable;
    discountFormMasterData: DiscountFormMasterData;
    discountFormDropDown: DiscountFormDropDown;
}