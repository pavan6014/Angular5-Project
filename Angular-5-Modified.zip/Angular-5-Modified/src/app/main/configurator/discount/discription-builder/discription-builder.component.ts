import { Component, OnInit, Output,Input } from '@angular/core';
import { DiscountFormDropDown,GetDiscountBuilderResponse, GetDiscriptionBuilder  } from '../../../configurator/discount/discount-interface';
import { DiscountService } from '../../../configurator/discount/discount.service';

@Component({
  selector: 'plm-discription-builder',
  templateUrl: './discription-builder.component.html',
  styleUrls: ['./discription-builder.component.css']
})
export class DiscriptionBuilderComponent implements OnInit {

  //@Input() discriptionBuilder: GetDiscountBuilder;
  @Input() discountFormDropDown: DiscountFormDropDown;
  @Input() discountsDiscriptionBuilder: GetDiscriptionBuilder;

  constructor() { }

  ngOnInit() {
  }

}
