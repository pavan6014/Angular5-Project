import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConfiguratorRoutingModule } from './configurator-routing.module';
import { OfferComponent } from './offer/offer.component';
import { OfferBucketGridViewComponent } from './offer/offer-bucket-grid-view/offer-bucket-grid-view.component';
import { AddOfferComponent } from './offer/add-offer/add-offer.component';
import { ConfiguratorProjectListComponent } from './offer/configurator-project-list/configurator-project-list.component';
import { OfferBucketComponent } from './offer/offer-bucket-grid-view/offer-bucket/offer-bucket.component';
import { ReadyToOfferListComponent } from './offer/offer-bucket-grid-view/ready-to-offer-list/ready-to-offer-list.component';
import { DiscountComponent,DialogOverviewExampleDialogs } from './discount/discount.component';
import { DiscountSearchComponent } from './discount/discount-search/discount-search.component';
import { AddDiscountCodeComponent } from './discount/add-discount-code/add-discount-code.component';
import { SearchDiscountComponent } from './discount/discount-search/search-discount/search-discount.component';
import { DiscountListComponent } from './discount/discount-search/discount-list/discount-list.component';
import { ProductComponent } from './product/product.component';
import { ProductSearchComponent } from './product/product-search/product-search.component';
import { AddProductComponent } from './product/add-product/add-product.component';
import { SearchProductComponent } from './product/product-search/search-product/search-product.component';
import { ProductListComponent } from './product/product-search/product-list/product-list.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatButtonModule, MatCheckboxModule,MatExpansionModule,MatAutocompleteModule,MatInputModule} from '@angular/material';
import {MatSelectModule} from '@angular/material/select';
import { Ng2PaginationModule } from 'ng2-pagination'; 
import { Ng2OrderModule } from 'ng2-order-pipe';
import { SharedModule } from '../../shared/shared.module';
import { NguiTabModule } from '@ngui/tab';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { IcomsStatusComponent } from './discount/icoms-status/icoms-status.component';
import { DiscriptionBuilderComponent } from './discount/discription-builder/discription-builder.component';
import { GiftCardComponent } from './discount/gift-card/gift-card.component';
import { MappingTableComponent } from './discount/mapping-table/mapping-table.component';
import { OscarComponent } from './discount/oscar/oscar.component';
import { MainPageComponent } from './discount/main-page/main-page.component';
import { OnlineComponent } from './discount/online/online.component';
import { CampaignCodeCreationPricingMethodComponent } from './discount/campaign-code-creation-pricing-method/campaign-code-creation-pricing-method.component';
import { CampaignCodeCreationPreReqsComponent } from './discount/campaign-code-creation-pre-reqs/campaign-code-creation-pre-reqs.component';
import { KeysPipe }  from '../configurator/pipes/keys.pipe';
import { GeneralInfoComponent } from './offer/add-offer/general-info/general-info.component';
import { ProductAssociationComponent } from './offer/add-offer/product-association/product-association.component';
import { DiscountAssociationComponent } from './offer/add-offer/discount-association/discount-association.component';
import { RelevancyRulesComponent } from './offer/add-offer/relevancy-rules/relevancy-rules.component';
import { ElgibilityRulesComponent } from './offer/add-offer/elgibility-rules/elgibility-rules.component';
import { PricingPinpointComponent } from './offer/add-offer/pricing-pinpoint/pricing-pinpoint.component';
import { EcommPinpointComponent } from './offer/add-offer/ecomm-pinpoint/ecomm-pinpoint.component';
import { OfferFromProjectComponent } from './offer/add-offer/offer-from-project/offer-from-project.component';
import {MatDialogModule} from '@angular/material/dialog';


@NgModule({
  imports: [
    CommonModule,
    ConfiguratorRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatExpansionModule,
    MatSelectModule,
    Ng2PaginationModule,
    Ng2OrderModule,
    SharedModule,
    NguiTabModule,
    MatDatepickerModule,
    MatAutocompleteModule,
    MatInputModule,
    MatDialogModule
  ],
  declarations: [
    OfferComponent,
    OfferBucketGridViewComponent,
    AddOfferComponent,
    ConfiguratorProjectListComponent,
    OfferBucketComponent,
    ReadyToOfferListComponent,
    DiscountComponent,
    DiscountSearchComponent,
    AddDiscountCodeComponent,
    SearchDiscountComponent,
    DiscountListComponent,
    ProductComponent,
    ProductSearchComponent,
    AddProductComponent,
    SearchProductComponent,
    ProductListComponent,
    IcomsStatusComponent,
    DiscriptionBuilderComponent,
    GiftCardComponent,
    MappingTableComponent,
    OscarComponent,
    MainPageComponent,
    OnlineComponent,
    CampaignCodeCreationPricingMethodComponent,
    CampaignCodeCreationPreReqsComponent,
    KeysPipe,
    GeneralInfoComponent,
    ProductAssociationComponent,
    DiscountAssociationComponent,
    RelevancyRulesComponent,
    ElgibilityRulesComponent,
    PricingPinpointComponent,
    EcommPinpointComponent,
    OfferFromProjectComponent,
    DialogOverviewExampleDialogs
  ],
   entryComponents: [DialogOverviewExampleDialogs],
})
export class ConfiguratorModule { }
