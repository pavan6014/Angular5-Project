import { Component, OnInit, Input } from '@angular/core';
import { GetofferFromProjectResponse } from '../add-offer-interface';
import { AddOfferService } from '../add-offer.service';

@Component({
  selector: 'plm-offer-from-project',
  templateUrl: './offer-from-project.component.html'
})
export class OfferFromProjectComponent implements OnInit {

  @Input() offerFromProject: GetofferFromProjectResponse;

  constructor() { }

  ngOnInit() {
  }

}
