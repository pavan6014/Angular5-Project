import { Component, OnInit, Input } from '@angular/core';
import { OfferFormDropDown } from '../add-offer-interface';
import { AddOfferService } from '../add-offer.service';

@Component({
  selector: 'plm-pricing-pinpoint',
  templateUrl: './pricing-pinpoint.component.html'
})
export class PricingPinpointComponent implements OnInit {

  @Input() offerFormDropDown: OfferFormDropDown;
  constructor() { }

  ngOnInit() {
  }

}
