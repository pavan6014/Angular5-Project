export interface GetDisAssoInterfaceResponse {
    actionResult: string;
    actionStatus: string;
    discountsAssoDropDown: discountsAssoDropDownList[];
    discountName: string;
    campaignCode: string;
}

export interface discountsAssoDropDownList{
    
}