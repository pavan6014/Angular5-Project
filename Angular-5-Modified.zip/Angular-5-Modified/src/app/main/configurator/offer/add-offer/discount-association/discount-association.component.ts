import { Component, OnInit, Input } from '@angular/core';
import { OfferFormDropDown } from '../add-offer-interface';
import { AddOfferService } from '../add-offer.service';

@Component({
  selector: 'plm-discount-association',
  templateUrl: './discount-association.component.html'
})
export class DiscountAssociationComponent implements OnInit {

  @Input() offerFormDropDown: OfferFormDropDown;
  constructor() { }

  ngOnInit() {
  }

}
