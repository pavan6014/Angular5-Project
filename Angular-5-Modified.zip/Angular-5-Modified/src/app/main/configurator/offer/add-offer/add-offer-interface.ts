import { expand } from "rxjs/operators/expand";

/* Offer form Project Interface starts here */
export interface GetofferFromProjectResponse {
    actionResult: string;
    actionStatus: string;
    projectCode: string;
    offerId:string;
    offerName:string;
    offerType: string;
    bundleType: string;
    offerStartDate: string;
    offerEndDate: string;
    offerDescription: string;
    psuType: GetPsuData[];
    price: string;
    priceSpec: string;
    discountType: string;
    discountValue: string;
    discountDuration: string;
    discountRule: string;
}

export interface GetPsuData {
    productGroup: string;
    productID: string;
    productName: string;
}
/* Offer form Project Interface ends here */


/* Offer form General Info Starts here */
export interface GetGeneralInfoInterfaceResponse {
    actionResult: string;
    actionStatus: string;
    offerId: string;
    offerName: string;
    offerDescription: string;
    offerBundle: Records[];
    offerCategory: Records[];
    offerStartDate: string;
    offerEndDate: string;
    lastUpdateDate: Date;
    infoTestDate: string;
    testDate: Date;
    productionLauanchDate: Date;
    offerStatus:Records[];
    vesion: string;
    createdByUser: string;
    sites: Records[] ;
    salesAdvise: string;
}
/* Offer form General Info ends here */

/* Master Drop down interface starts here */
export interface OfferFormMasterData {
    actionResult: string;
    actionStatus:string;
    commonMasterData: CommonMasterData[];
    discountResponse: DiscountAssoResponse;
    productResponse: ProductAssoResponse;
}

export interface DiscountAssoResponse {
    actionResult: string;
    actionStatus:string;
    discounts: DiscountsData[];
}

export interface DiscountsData{
    prodId: string;
    productName: string;
    productType: string;
    psu: string;
    packageCode: string; 
}

export interface ProductAssoResponse {
    actionResult: string;
    actionStatus:string;
    products: ProductsData[];
}

export interface ProductsData{
    prodId: string;
    productName: string;
    productType: string;
    psu: string;
    packageCode: string; 
}

export interface CommonMasterData {
    name: string;
    records: Records[];
}

export interface Records {
    key: number;
    value: string;
}

export interface OfferFormDropDown {
    PINPOINT_STATUS: Records[];
    CHANNELSLABEL: Records[];
    ADDON_TYPE: Records[];
    DVR: Records[];
    DATAEQUIP: Records[];
    VIDEOEQUIP: Records[];
    PSU_INSTL_TYPE: Records[];
    PSU_BASE_OFFER_ELIGI: Records[];
    RATEGRP_EXCLUSIONLIST: Records[];
    STATICINTENTLIST: Records[];
    STATICSUBINTENTLIST: Records[];
    PAYLAUNCHMODE: Records[];
    ECOM_PINPOINT_STATUS: Records[];
    BUNDLE_MASTER: Records[];
    OFFER_CATEGORY_MASTER: Records[];
    STATUS_MASTER: Records[];
    SITES: Records[];
    DISCOUNTS: DiscountsData[];
    PRODUCTS: ProductsData[];
}


export interface Records {
    key: number;
    value: string;
}

export interface GetPsuData {
    productGroup: string;
    productID: string;
    productName: string;
}
/* Master Drop down interface ends here */
