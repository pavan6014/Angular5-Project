export interface EcommPinpointInterface {
}
