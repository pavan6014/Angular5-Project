export interface PricingPinpointInterface {
}
