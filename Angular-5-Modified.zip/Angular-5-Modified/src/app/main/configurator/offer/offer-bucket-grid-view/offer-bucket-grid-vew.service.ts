import { Injectable,  } from '@angular/core';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/empty';
import 'rxjs/add/operator/retry';
import { BreadCrumb } from '../../../../shared/services/bread-crumb';
import { AppConfigService } from '../../../../shared/services/app-config.service';
import { GetConfiguratorExistingPsu, GetConfiguratorExistingResponse } from './offer-bucket-grid-vew-interface';
import { ConfiguratorDataService } from '../../configurator-data.service';

@Injectable()
export class OfferBucketGridVewService {
  
  projectCode : any;
	constructor(private http: HttpClient, private appConfigService: AppConfigService, private route: ActivatedRoute, private configuratorDataService: ConfiguratorDataService) {
    // this.route.params.subscribe(params => {
    //   console.log(params);
      
    //   console.log(params['projectCode']);
    //   if (params['projectCode']) { 
    //     //console.log(params['projectCode']);
    //     this.projectCode = params['projectCode'];
    //   }
    // });

   }
	
	getConfiguratorGridList(projectCode): Observable<any>{
    // console.log(this.projectCode);
    // const getConfiguratorBoxViewList = this.appConfigService.url + 'data/' + this.projectCode + '.json';
    
    //  return this.http
    //   .get(getConfiguratorBoxViewList)
    //    .map((response: any) => {
    //      return response;
    //    })
    //    .catch(this.handleError);

    const getConfiguratorBoxViewList = this.appConfigService.urlConstants['PLM_CONFIGURATOR_PSU_OFFERLIST'];
    return this.http
      .get(getConfiguratorBoxViewList)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }

  private handleError(error: Response) {
    return Observable.throw(error.statusText);
  }

}
