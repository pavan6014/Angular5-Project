import { Component, OnInit } from '@angular/core';
import {FormControl} from '@angular/forms';
import { Router } from '@angular/router';
import { GetConfiguratorExistingPsu, GetConfiguratorExistingResponse, CreatePsu, PSUProduct, Specifications,CreateOffers } from './offer-bucket-grid-vew-interface';
import { OfferBucketGridVewService } from './offer-bucket-grid-vew.service';
import { ConfiguratorDataService } from '../../configurator-data.service';

@Component({
  selector: 'plm-offer-bucket-grid-view',
  templateUrl: './offer-bucket-grid-view.component.html',
  providers: [OfferBucketGridVewService, ConfiguratorDataService]
})
export class OfferBucketGridViewComponent implements OnInit {

  private psu: any;
  private psu1P: CreatePsu[];
  private psu2P: CreatePsu[];
  private psu3P: CreatePsu[];
  private psu4P: CreatePsu[];
  private offersList: CreateOffers[];
  private key: string;
  private reverse: boolean;
  private showSearch: boolean;
  private projectCode: string;
  
  private getConfiguratorExistingPsu: GetConfiguratorExistingResponse;

  constructor(private configuratorDataService: ConfiguratorDataService, private OfferBucketGridViewService:OfferBucketGridVewService, private router: Router){
    this.psu1P = [];
    this.psu2P = [];
    this.psu3P = [];
    this.psu4P = [];
    this.offersList= [];   
  }

  ngOnInit() {
    this.getConfiguratorGridList();
  }

  getConfiguratorGridList(){
    this.OfferBucketGridViewService.getConfiguratorGridList(this.configuratorDataService.createPSUProjectID)
        .subscribe(
            data => {
                this.projectCode = data.projectCode;
                this.getConfiguratorExistingPsu = data;
                this.psu = data.psu;
                this.psu1P = data.psu['1P'];
                this.psu2P = data.psu['2P'];
                this.psu3P = data.psu['3P'];
                this.psu4P = data.psu['4P'];
                this.offersList = data.offers;
                console.log(this.projectCode);
            },
            error => {
                //console.log("Error :: " + error)
            }
        );
  }

  


  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon(){
    this.showSearch = !this.showSearch;
  }

}
