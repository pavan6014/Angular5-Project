import { Component, OnInit, Input } from '@angular/core';
import { GetConfiguratorExistingPsu, GetConfiguratorExistingResponse, CreatePsu, PSUProduct, Specifications,CreateOffers } from '../offer-bucket-grid-vew-interface';
import { OfferBucketGridVewService } from '../offer-bucket-grid-vew.service';

@Component({
  selector: 'plm-ready-to-offer-list',
  templateUrl: './ready-to-offer-list.component.html'
})
export class ReadyToOfferListComponent implements OnInit {

  @Input() offersListChild: CreateOffers[];
  
  constructor() { }

  ngOnInit() {
    console.log("offersList");
  }

}
