import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-offer',
  templateUrl: './offer.component.html'
})
export class OfferComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
