import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GetConfiguratorProjectList, GetConfiguratorProjectListResponse } from './configurator-project-list-interface';
import { ConfiguratorProjectListService } from './configurator-project-list.service';
import { ConfiguratorDataService } from '../../configurator-data.service';

@Component({
  selector: 'plm-configurator-project-list',
  templateUrl: './configurator-project-list.component.html',
  providers: [ConfiguratorProjectListService, ConfiguratorDataService]
})
export class ConfiguratorProjectListComponent implements OnInit {
  private filterByCode: string;
  private filterByType: string;
  private filterByStartDate: string;
  private filterByEndDate: string;
  private filterByCategory: string;
  private filterBySite: Array<string>;
  private filterByStatus: string;
  private showSearch: boolean;
  private key: string;
  private reverse: boolean;

  private configuratorProjectList: GetConfiguratorProjectListResponse;
  private createProjectForm: GetConfiguratorProjectListResponse;

  constructor(private createMarketingOfferService:ConfiguratorProjectListService, private router: Router, private configuratorDataService: ConfiguratorDataService){
    this.getConfiguratorProjectList();
  }

  ngOnInit() {
    this.filterByCode = '';
    this.filterByType = '';
    this.filterByStartDate = '';
    this.filterByEndDate = '';
    this.filterByCategory = '';
    this.filterBySite = [];
    this.filterByStatus = '';
    this.configuratorDataService.createProjectFormUpdated.subscribe(
      data => {
          this.createProjectForm = data;
      },
      error => {
          console.log('Error :: ' + error);
      }
    );
  }
  
  getConfiguratorProjectList(){
    this.createMarketingOfferService.getConfiguratorProjectList()
        .subscribe(
            data => {
                this.configuratorProjectList = data;
                //console.log(this.getConfiguratorProjectList);
            },
            error => {
                //console.log("Error :: " + error)
            }
        );
  }

  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon(){
    this.showSearch = !this.showSearch;
  }

  moveToConfiguratorGrid(projectCode) {
    this.configuratorDataService.createPSUProjectID = projectCode;
    console.log(this.configuratorDataService.createPSUProjectID);
    this.router.navigate(['/plm-work-flow/configurator/offer/offer-table']);
  }

}
