import { Injectable, EventEmitter } from '@angular/core';
import { GetConfiguratorExistingPsu } from '../configurator/offer/offer-bucket-grid-view/offer-bucket-grid-vew-interface';

@Injectable()
export class ConfiguratorDataService {

  public createPSUProjectID: string;
  public createProjectForm: GetConfiguratorExistingPsu;
  public createProjectFormUpdated: any;

  public constructor() {
    this.createProjectFormUpdated  = new EventEmitter();
  }
   
  setCreateProjectForm(formData) {
    this.createProjectForm = formData;
    this.createProjectFormUpdated.emit(this.createProjectForm);
  }

  getCreateProjectForm() {
    return this.createProjectForm;
  }

   
}
