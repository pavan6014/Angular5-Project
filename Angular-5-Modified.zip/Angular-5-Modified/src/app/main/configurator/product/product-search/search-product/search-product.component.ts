import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-search-product',
  templateUrl: './search-product.component.html'
})
export class SearchProductComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
