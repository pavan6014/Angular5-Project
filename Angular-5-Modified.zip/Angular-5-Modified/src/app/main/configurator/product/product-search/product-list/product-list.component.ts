import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-product-list',
  templateUrl: './product-list.component.html'
})
export class ProductListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
