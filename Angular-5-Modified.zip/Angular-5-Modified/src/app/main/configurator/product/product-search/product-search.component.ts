import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-product-search',
  templateUrl: './product-search.component.html'
})
export class ProductSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
