export const environment = {
  production: false,
  envName: 'qa',
  host: '/ice',
  isDebugMode: false
};

