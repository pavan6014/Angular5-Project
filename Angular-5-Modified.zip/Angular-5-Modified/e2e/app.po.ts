import { browser, by, element } from 'protractor';

export class PLMPage {
  navigateTo() {
    return browser.get('/');
  }

  getParagraphText() {
    return element(by.css('plm-root h1')).getText();
  }
}
