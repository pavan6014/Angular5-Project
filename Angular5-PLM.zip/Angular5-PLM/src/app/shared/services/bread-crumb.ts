export interface BreadCrumb {
    name: string;
    url: string;
}

