import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-omc-prod-queue',
  templateUrl: './omc-prod-queue.component.html'
})
export class OmcProdQueueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
