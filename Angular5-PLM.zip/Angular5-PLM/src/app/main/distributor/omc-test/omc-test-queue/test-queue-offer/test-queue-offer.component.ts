import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-test-queue-offer',
  templateUrl: './test-queue-offer.component.html'
})
export class TestQueueOfferComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
