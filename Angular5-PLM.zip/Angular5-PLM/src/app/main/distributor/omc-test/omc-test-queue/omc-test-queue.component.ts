import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-omc-test-queue',
  templateUrl: './omc-test-queue.component.html'
})
export class OmcTestQueueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
