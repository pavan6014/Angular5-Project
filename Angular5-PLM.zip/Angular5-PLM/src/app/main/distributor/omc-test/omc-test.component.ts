import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-omc-test',
  templateUrl: './omc-test.component.html'
})
export class OmcTestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
