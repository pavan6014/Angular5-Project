import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-uat-users',
  templateUrl: './uat-users.component.html'
})
export class UatUsersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
