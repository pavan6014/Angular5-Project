import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-offer-grid',
  templateUrl: './offer-grid.component.html'
})
export class OfferGridComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
