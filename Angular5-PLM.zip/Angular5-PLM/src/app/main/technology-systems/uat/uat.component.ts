import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-uat',
  templateUrl: './uat.component.html'
})
export class UatComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
