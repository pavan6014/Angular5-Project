import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { AddUserService } from './add-user.service';
import { LDAPUserSearch, AddUserFormData, AddNewUserRequest, AddNewUserResponse } from './add-user.interface';
import { BreadCrumb } from '../../../shared/services/bread-crumb';
import { UtilitiesService } from '../../../shared/services/utilities.service';

@Component({
    selector: 'plm-add-user',
    templateUrl: './add-user.component.html',
    styleUrls: ['./add-user.component.css'],
    providers: [AddUserService, UtilitiesService]
})
export class AddUserComponent implements OnInit {

    @ViewChild('addUserForm') public addUserForm: NgForm;
    private dropdownList = [];
    private selectedItems = [];
    private dropdownSettings = {};
    private breadCrumbs: BreadCrumb[];
    private newUserAdded: boolean;
    private newUserNotAdded: boolean;
    private invalidEmail: boolean;
    private emailNotExists: boolean;
    private usersData: AddUserFormData;
    private email: string;
    private fname: string;
    private lname: string;
    private formDataAvailable: boolean;

    constructor(private addUserService: AddUserService, private utilitiesService: UtilitiesService) {
        this.newUserAdded = false;
        this.newUserNotAdded = false;
        this.invalidEmail = false;
        this.emailNotExists = false;
        this.formDataAvailable = false;
        this.breadCrumbs = this.addUserService.getBreadCrumbs();
        this.getFormData();
    }

    getFormData() {
        this.addUserService.getFormData()
            .subscribe(
                data => {
                    this.usersData = data;
                    this.populateData(data);
                    this.formDataAvailable = true;
                },
                error => {
                    console.log("Error :: " + error)
                }
            );
    }

    populateData(data) {
        this.dropdownSettings = {
            singleSelection: false,
            text: "Select Work Group",
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            enableSearchFilter: true,
            classes: "myclass custom-class",
            badgeShowLimit: 2,
            maxHeight: 120
        };
        for (const workGroupModel of data.workGroupModels) {
            this.dropdownList.push({
                "id": workGroupModel.workGroupId,
                "itemName": workGroupModel.workGroupName,
            })
        }
    }


    getUsersDetails(emailValue) {
        this.emailNotExists = false;
        this.invalidEmail = false;
        if (!this.utilitiesService.isEmailAddress(emailValue.value.toString())){
            this.invalidEmail = true;
            return false;
        }
        this.addUserService.getUserDetails(emailValue)
            .subscribe(
                data => {
                    if (Object.keys(data).length === 0 ) {
                        this.emailNotExists = true;
                    } else {
                        this.email = data.email;
                        this.fname = data.givenName;
                        this.lname = data.displayName;
                    }
                },
                error => {
                    console.log("Error :: " + error)
                }
            );
    }

    addNewUser(){
        this.newUserAdded = false;
        this.newUserNotAdded = false;
        const workGroupIDs: string[] = [];
        for (let i=0; i<this.selectedItems.length; i++) {
            workGroupIDs.push(this.selectedItems[i].id.toString());
        }
        
        let reqObj: AddNewUserRequest;
        reqObj = {
            "email" : this.addUserForm.value.email,
            "roleId": Number(this.addUserForm.value.rolesDropdown), 
            "firstName": this.fname,
            "lastName": this.lname,
            "statusId": Number(this.addUserForm.value.statusDropDown),
            "workGroupId": workGroupIDs,
            "defaultWorkGroup": [Number(this.addUserForm.value.workGroupDropDown)]
        };
        this.addUserService.addNewUser(reqObj)
            .subscribe(
                data => {
                    if (data.actionStatus == "SUCCESS") {
                        this.newUserAdded = true;
                    } else {
                        this.newUserNotAdded = true;
                    }
                },
                error => {
                    console.log("Error :: " + error)
                }
            );
    }

    ngOnInit() {

    }
    onItemSelect(item: any) {
        //console.log(this.selectedItems);
    }
    OnItemDeSelect(item: any) {
        //console.log(this.selectedItems);
    }
    onSelectAll(items: any) {
        //console.log(items);
    }
    onDeSelectAll(items: any) {
        //console.log(items);
    }
}
