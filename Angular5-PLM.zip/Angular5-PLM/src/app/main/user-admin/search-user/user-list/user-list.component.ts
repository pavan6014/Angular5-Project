import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChange, SimpleChanges } from '@angular/core';
import { SearchUserService } from '../search-user.service';
import { SearchUserModel, ModifyUserRequest, ModifyUser } from '../search-user.interface';

@Component({
  selector: 'plm-user-list',
  templateUrl: './user-list.component.html'
})
export class UserListComponent implements OnInit, OnChanges {
  @Input() userList: SearchUserModel[];
  @Output() statusUpdated: EventEmitter<boolean> = new EventEmitter<boolean>();
  private users: string;
  private filterByName: string;
  private filterByEmail: string;
  private filterByStatus: string;
  private showSearch: boolean;
  private key: string;
  private reverse: boolean;
  constructor(private searchUserService: SearchUserService) {
    this.filterByName = '';
    this.filterByEmail = '';
    this.filterByStatus = '';
    this.key = 'name';
    this.reverse = false;
  }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges) {
    const userList: SimpleChange = changes.userList;
    //console.log('prev value: ', userList.previousValue);
    //console.log('got name: ', userList.currentValue);
    this.userList = ((typeof userList.currentValue !== 'undefined') && (typeof userList.currentValue.searchUserModel !== 'undefined')) ? JSON.parse(JSON.stringify(userList.currentValue.searchUserModel)) : [];
    if (this.userList.length > 0) {
      for (let i = 0; i < this.userList.length; i++) {
        this.userList[i].checked = false;
        this.userList[i].selected = this.userList[i].statusid.statusId;
        this.userList[i].name = this.userList[i].firstname+' '+ this.userList[i].lastname;
        this.userList[i].status = this.userList[i].statusid.statusName;
        this.userList[i].statusArray = [
          { 'statusId': 1, 'statusName': 'Active' },
          { 'statusId': 2, 'statusName': 'InActive' }
        ];
      }
    }
    
    this.users = JSON.stringify(this.userList);
  }

  modifyUserData(index) {
    this.userList[index].statusid.statusId = this.userList[index].selected;
    for (const statusObj of this.userList[index].statusArray) {
        if ((typeof statusObj !== 'undefined') && (Number(this.userList[index].selected) === Number(statusObj.statusId))) {
          this.userList[index].statusid.statusName = statusObj.statusName;
        }
    }
  }

  updateUsersData() {
    const reqObjArray: ModifyUserRequest = {
      "requests" : []
    };
    let count =0;
    if (this.userList.length > 0) {
      for (let i = 0; i < this.userList.length; i++) {
        if (this.userList[i].checked) {
          count++;
          const reqObj: ModifyUser = {
            'userid': this.userList[i].userid,
            'statusid': this.userList[i].statusid.statusId,
            'roleid': '',
            'firstname': this.userList[i].firstname,
            'lastname': this.userList[i].lastname,
            'email': this.userList[i].email
          }
          reqObjArray.requests.push(reqObj);
        }
      }
    }
    if (count > 0) {
      this.searchUserService.updateUsers(reqObjArray)
      .subscribe(
          data => {
            if (data.actionStatus === "SUCCESS") {
              this.statusUpdated.emit(true);
            } else {
              this.statusUpdated.emit(false);
            }
          },
          error => {
              console.log("Error :: " + error)
          }
      );
    }
  }

  toggleSearchIcon(){
    this.showSearch = !this.showSearch;
  }
  
  sort(key){
    this.key = key;
    this.reverse = !this.reverse;
  }
  
}
