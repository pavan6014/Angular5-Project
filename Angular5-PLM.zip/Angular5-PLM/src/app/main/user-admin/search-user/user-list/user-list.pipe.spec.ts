import { UserListPipe } from './user-list.pipe';

describe('UserListPipe', () => {
  it('create an instance', () => {
    const pipe = new UserListPipe();
    expect(pipe).toBeTruthy();
  });
});
