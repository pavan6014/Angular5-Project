export interface SearchUserRequest {
    searchcriteria: string;
    criteriatype: string;
}

export interface SearchUserModel {
        userid: string;
        firstname: string;
        lastname: string;
        email: string;
        lastLogon: string;
        statusid: StatusID,
        statusArray: StatusID[],
        checked: boolean,
        selected: number,
        name: string,
        status: string
}

export interface StatusID {
    statusId: number;
    statusName: string;
}

export interface SearchUserResponse {
    actionResult: string;
    actionStatus: string;
    searchUserModel: SearchUserModel[];
}

export interface ModifyUser {
    userid: string;
    statusid: number;
    roleid: string;
    firstname: string;
    lastname: string;
    email: string;
}

export interface ModifyUserRequest {
    requests: ModifyUser[];
}

export interface ModifyUserResponse {
    actionResult: string;
    actionStatus: string;
    searchUserModel: SearchUserModel[];
}

