import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/empty';
import 'rxjs/add/operator/retry';
import { BreadCrumb } from '../../../shared/services/bread-crumb';
import { AppConfigService } from '../../../shared/services/app-config.service';
import { SearchUserResponse, SearchUserRequest, ModifyUserRequest } from './search-user.interface';

@Injectable()
export class SearchUserService {

  constructor(private http: HttpClient, private appConfigService: AppConfigService) { }

  getBreadCrumbs(): BreadCrumb[] {
    return [
      { 'name': 'Home', 'url': 'dashboard' },
      { 'name': 'User Admin', 'url': '' },
      { 'name': 'Search User', 'url': '' },
    ];
  }

  getSearchCriteria(): Observable<any>{
    // const getUserDetailsURL = this.appConfigService.protocol + '://' + this.appConfigService.host + ':' + this.appConfigService.port + '/' + this.appConfigService.urlConstants['PLM_ADD_USER_FORM_DATA'];
    const getSearchCriteria = this.appConfigService.urlConstants['PLM_SEARCH_CRITERIA'];
    return this.http
      .get(getSearchCriteria)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }

  getUserList(searchCriteria:SearchUserRequest ): Observable<SearchUserResponse>{
    // const getUserList = this.appConfigService.protocol + '://' + this.appConfigService.host + ':' + this.appConfigService.port + '/' + this.appConfigService.urlConstants['PLM_SEARCH_USER_SEARCH'];
    // return this.http
    //   .post(getUserDetailsURL, searchCriteria)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
    const getUserList = this.appConfigService.urlConstants['PLM_SEARCH_USER_SEARCH'];
    return this.http
      .get(getUserList)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }

  updateUsers(userList:ModifyUserRequest ): Observable<SearchUserResponse>{
    // const updateUsers = this.appConfigService.protocol + '://' + this.appConfigService.host + ':' + this.appConfigService.port + '/' + this.appConfigService.urlConstants['PLM_UPDATE_USER'];
    // return this.http
    //   .post(updateUsers, userList)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
    const updateUsers = this.appConfigService.urlConstants['PLM_UPDATE_USER'];
    return this.http
      .get(updateUsers)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }

  private handleError(error: Response) {
    return Observable.throw(error.statusText);
  }


}
