import { Component, OnInit, Input } from '@angular/core';
import { OfferFormDropDown,GetGeneralInfoInterfaceResponse } from '../add-offer-interface';
import { AddOfferService } from '../add-offer.service';


@Component({
  selector: 'plm-general-info',
  templateUrl: './general-info.component.html'
})
export class GeneralInfoComponent implements OnInit {

  @Input() offerFormDropDown: OfferFormDropDown;
  @Input() offerGeneralInfo: GetGeneralInfoInterfaceResponse;

  constructor() { }

  ngOnInit() {
  }

}
