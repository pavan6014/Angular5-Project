export interface RelevancyRulesInterface {
}
