export interface ElgibilityRulesInterface {
}
