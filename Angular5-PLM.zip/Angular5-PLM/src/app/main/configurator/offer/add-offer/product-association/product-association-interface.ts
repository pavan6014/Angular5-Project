export interface GetProductAssoInterfaceResponse {
    actionResult: string;
    actionStatus: string;
    productAssoDropDown: productAssoDropDownList[];
    productName: string;
    productType: string;
    psu: string;
    packageCode: string;  
}

export interface productAssoDropDownList{
    
}
