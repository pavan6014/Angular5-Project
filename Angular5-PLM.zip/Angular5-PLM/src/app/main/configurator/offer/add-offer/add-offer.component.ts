import { Component, OnInit } from '@angular/core';
import {FormControl} from '@angular/forms';
import { Router } from '@angular/router';
import { GetGeneralInfoInterfaceResponse, Records, OfferFormDropDown, OfferFormMasterData,GetofferFromProjectResponse } from './add-offer-interface';
import { AddOfferService } from './add-offer.service';

@Component({
  selector: 'plm-add-offer',
  templateUrl: './add-offer.component.html',
  providers: [AddOfferService]
})
export class AddOfferComponent implements OnInit {

  private key: string;
  private reverse: boolean;
  private showSearch: boolean;
  private masterData: OfferFormMasterData;
  private offerFormDropDown: OfferFormDropDown;
  private offerFromProject: GetofferFromProjectResponse;
  private offerGeneralInfo: GetGeneralInfoInterfaceResponse;
  
  constructor(private addOfferService:AddOfferService, private router: Router){
    this.getConfiguratorFormData();
    this.getConfiguratorOfferFromProject();
    this.initializeOfferFormDropDown();
  }

  getConfiguratorFormData(){
    this.addOfferService.getConfiguratorMasterFormDropDown()
        .subscribe(
            data => {
                this.masterData = data;
                console.log(this.masterData);
                this.populateFormFieldValues();
            },
            error => {
                //console.log("Error :: " + error)
            }
        );
  }

  getConfiguratorOfferFromProject(){
    this.addOfferService.getConfiguratorOfferFromProject()
        .subscribe(
            data => {
                this.offerFromProject = data.mrktingOfferTxnDet;
                this.offerGeneralInfo = data.generalInfoMapTxnDet;
                console.log(this.offerGeneralInfo);
            },
            error => {
                //console.log("Error :: " + error)
            }
        );
  }

  ngOnInit() {
    
  }

  populateFormFieldValues(){
    for (let i=0; i<this.masterData.commonMasterData.length; i++) {
      const currentMasterData = this.masterData.commonMasterData[i];
      this.offerFormDropDown[currentMasterData.name] = currentMasterData.records;
    }
    console.log(this.offerFormDropDown);
  }

  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon(){
    this.showSearch = !this.showSearch;
  }

  initializeOfferFormDropDown(){
    this.offerFormDropDown = {
      'PINPOINT_STATUS': [],
      'CHANNELSLABEL': [],
      'ADDON_TYPE': [],
      'DVR': [],
      'DATAEQUIP': [],
      'VIDEOEQUIP': [],
      'PSU_INSTL_TYPE': [],
      'PSU_BASE_OFFER_ELIGI': [],
      'RATEGRP_EXCLUSIONLIST': [],
      'STATICINTENTLIST': [],
      'STATICSUBINTENTLIST': [],
      'PAYLAUNCHMODE': [],
      'ECOM_PINPOINT_STATUS': [],
      'BUNDLE_MASTER': [],
      'OFFER_CATEGORY_MASTER': [],
      'STATUS_MASTER': [],
      "SITES": [],
      "DISCOUNTS": [],
      "PRODUCTS": []
    }
  }

}
