import { Component, OnInit, Input } from '@angular/core';
import { OfferFormDropDown } from '../add-offer-interface';
import { AddOfferService } from '../add-offer.service';

@Component({
  selector: 'plm-ecomm-pinpoint',
  templateUrl: './ecomm-pinpoint.component.html'
})
export class EcommPinpointComponent implements OnInit {

  @Input() offerFormDropDown: OfferFormDropDown;

  constructor() { }

  ngOnInit() {
  }

}
