import { Component, OnInit, Input } from '@angular/core';
import { OfferFormDropDown } from '../add-offer-interface';
import { AddOfferService } from '../add-offer.service';

@Component({
  selector: 'plm-product-association',
  templateUrl: './product-association.component.html'
})
export class ProductAssociationComponent implements OnInit {

  @Input() offerFormDropDown: OfferFormDropDown;
  constructor() { }

  ngOnInit() {
  }

}
