import { Component, OnInit, Input } from '@angular/core';
import { OfferFormDropDown } from '../add-offer-interface';
import { AddOfferService } from '../add-offer.service';

@Component({
  selector: 'plm-relevancy-rules',
  templateUrl: './relevancy-rules.component.html'
})
export class RelevancyRulesComponent implements OnInit {

  @Input() offerFormDropDown: OfferFormDropDown;
  constructor() { }

  ngOnInit() {
  }

}
