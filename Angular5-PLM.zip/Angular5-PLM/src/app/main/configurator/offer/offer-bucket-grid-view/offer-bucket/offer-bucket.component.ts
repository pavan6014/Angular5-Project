import { Component, OnInit, Input, Output, EventEmitter, ElementRef, OnChanges } from '@angular/core';
import { GetConfiguratorExistingPsu, GetConfiguratorExistingResponse, CreatePsu, PSUProduct, Specifications,CreateOffers } from '../offer-bucket-grid-vew-interface';
import { OfferBucketGridVewService } from '../offer-bucket-grid-vew.service';

@Component({
  selector: 'plm-offer-bucket',
  templateUrl: './offer-bucket.component.html'
})
export class OfferBucketComponent implements OnInit {

  @Input() projectCode: string;
  @Input() psu: CreatePsu;
  @Input() offersList: CreateOffers;
  @Input() psuType: string;
  @Input() psuCount: number;
  private isDataProduct: boolean;
  private dataProductVal: string;
  private isVideoProduct: boolean;
  private videoProductVal: string;
  private isPhoneProduct: boolean;
  private phoneProductVal: string;
  private isHomeProduct: boolean;
  private homeProductVal: string;
  private selected: string[];
  private productsArray: string[];
  private noDataArray: string[];

  constructor() {
    this.isDataProduct = false;
    this.isPhoneProduct = false;
    this.isVideoProduct = false;
    this.isHomeProduct = false;
    this.productsArray = [];
    this.noDataArray = [];
   }

  ngOnInit() {
    const products = this.psu.product;
    for (let i=0; i<products.length; i++) {
      this.productsArray.push(products[i].productGroup);
      this.showProducts(products[i]);
    }    
    this.selected = this.productsArray;
    for (let j=0; j<this.psuCount; j++) {
      this.noDataArray.push("No Data");
    }
  }

  showProducts(product) {
    if (product.productGroup === 'Data') {
      this.isDataProduct = true;
      this.dataProductVal = product.productName;
    } else if (product.productGroup === 'Phone') {
      this.isPhoneProduct = true;
      this.phoneProductVal = product.productName;
    } else if (product.productGroup === 'Video') {
      this.isVideoProduct = true;
      this.videoProductVal = product.productName;
    } else if (product.productGroup === 'Home') {
      this.isHomeProduct = true;
      this.homeProductVal = product.productName;
    } else {
    }
  }

}
