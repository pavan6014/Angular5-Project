export interface GetConfiguratorExistingPsu {
  projectCode: string;
  projectType: string;
  projectStartDate: string;
  projectEndDate: string;
  projectCategoery: string;
  site:Array<string>;
  status:string;
}

export interface CreatePsu {
  offerID: string;
  sequenceNo: string;
  psuType: string;
  product: PSUProduct[];
  specification: Specifications
}

export interface PSUProduct{
  productGroup: string;
  productID: string;
  productName: string;
}

export interface Specifications {
  price: string;
  discountType: string;
  discountDuration: string;
  priceSpecification: string;
  discountValue: string;
}

export interface CreateOffers {
  projectCode: string;
  offerId: string;
  startDt: string;
  releaseDt: string;
  status: string;
  releaseCd: string;
}

export interface GetConfiguratorExistingResponse {
    actionResult: string;
    actionStatus: string;
    getConfiguratorProjectList: GetConfiguratorExistingPsu[];
    getConfiguratorOffersList: CreateOffers[];
}
