import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-add-product',
  templateUrl: './add-product.component.html'
})
export class AddProductComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
