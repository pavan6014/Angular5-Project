import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-discount-search',
  templateUrl: './discount-search.component.html'
})
export class DiscountSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
