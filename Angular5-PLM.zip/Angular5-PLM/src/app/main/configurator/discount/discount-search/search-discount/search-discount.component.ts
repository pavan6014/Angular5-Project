import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-search-discount',
  templateUrl: './search-discount.component.html'
})
export class SearchDiscountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
