import { Component, OnInit, Input, Output } from '@angular/core';
import { GetCampaignCodePricingPreReq,GetCampaignCodePricingPreReqResponse,
   DiscMapPreRequisite, TeCode } from '../../../configurator/discount/discount-interface';

@Component({
  selector: 'plm-campaign-code-creation-pre-reqs',
  templateUrl: './campaign-code-creation-pre-reqs.component.html',
  styleUrls: ['./campaign-code-creation-pre-reqs.component.css']
})
export class CampaignCodeCreationPreReqsComponent implements OnInit {

  @Input() campaignCodeMethodPreReq: GetCampaignCodePricingPreReq;
  @Input() discMapPreRequisite: DiscMapPreRequisite;
  @Input() teData: TeCode;
 
  constructor() { }

  ngOnInit() {
  }

}
