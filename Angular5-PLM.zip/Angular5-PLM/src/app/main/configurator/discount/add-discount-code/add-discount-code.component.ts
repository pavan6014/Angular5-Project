import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'plm-add-discount-code',
  templateUrl: './add-discount-code.component.html'
})
export class AddDiscountCodeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
