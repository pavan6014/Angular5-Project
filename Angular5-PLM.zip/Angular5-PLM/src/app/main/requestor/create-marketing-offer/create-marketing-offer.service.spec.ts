import { TestBed, inject } from '@angular/core/testing';

import { CreateMarketingOfferService } from './create-marketing-offer.service';

describe('CreateMarketingOfferService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CreateMarketingOfferService]
    });
  });

  it('should be created', inject([CreateMarketingOfferService], (service: CreateMarketingOfferService) => {
    expect(service).toBeTruthy();
  }));
});
