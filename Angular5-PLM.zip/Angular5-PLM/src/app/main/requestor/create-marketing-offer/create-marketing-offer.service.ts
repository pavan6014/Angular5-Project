import { Injectable } from '@angular/core';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/empty';
import 'rxjs/add/operator/retry';
import { BreadCrumb } from '../../../shared/services/bread-crumb';
import { AppConfigService } from '../../../shared/services/app-config.service';
import { ModifyMarketingOffer } from '../requestor.interface';
import { GetMarketingOffer, GetMarketingOffersResponse, SubmitAddMarketingOfferResponse } from './create-marketing-offer.interface';

@Injectable()
export class CreateMarketingOfferService {

  constructor(private http: HttpClient, private appConfigService: AppConfigService) { }

  getBreadCrumbs(): BreadCrumb[] {
    return [
      { 'name': 'Home', 'url': 'dashboard' },
      { 'name': 'User Admin', 'url': '' },
      { 'name': 'Search User', 'url': '' },
    ];
  }

  getAddMarketingOfferFormData(projectCode): Observable<any>{
    // const getAddMarketingOfferFormDataURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_GET_ADD_MARKETING_FORM_DATA'] + '/' +projectCode;
    // return this.http
    //   .get(getAddMarketingOfferFormDataURL)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
    const getMarketingOffers = this.appConfigService.urlConstants['PLM_ADD_MARKETING_OFFER_FORM_DATA'];
    return this.http
      .get(getMarketingOffers)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }

  getAddMarketingDateForOfferId(projectCode, offerID): Observable<ModifyMarketingOffer>{
    // const getAddMarketingOfferFormDataURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_GET_ADD_MARKETING_DATA_BY_OFFERID'] + '/' +projectCode + '/' +offerID;
    // return this.http
    //   .get(getAddMarketingOfferFormDataURL)
    //   .map((response: Response) => {
    //     return response;
    //   })
    //   .catch(this.handleError);
    const getMarketingOffers = this.appConfigService.urlConstants['PLM_ADD_MARKETING_FORM_BY_OFFER_ID'];
    return this.http
      .get(getMarketingOffers)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }

  postAddMarketingOfferFormData(reqObj): Observable<SubmitAddMarketingOfferResponse> {
    if (reqObj.offerId !== '') {
      // const putAddMarketingOfferFormDataURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_UPDATE_MARKETING_DATA'];
      // return this.http
      //   .put(putAddMarketingOfferFormDataURL, reqObj)
      //   .map((response: Response) => {
      //     return response;
      //   })
      //   .catch(this.handleError);
    } else {
        // const postAddMarketingOfferFormDataURL = this.appConfigService.url + '/' + this.appConfigService.urlConstants['PLM_ADD_MARKETING_DATA'];
      // return this.http
      //   .post(postAddMarketingOfferFormDataURL, reqObj)
      //   .map((response: Response) => {
      //     return response;
      //   })
      //   .catch(this.handleError);
    }
    const addMarketingOfferResponse = this.appConfigService.urlConstants['PLM_ADD_MARKETING_OFFER_RESPONSE'];
    console.log(JSON.stringify(reqObj));
    return this.http
      .get(addMarketingOfferResponse)
      .map((response: Response) => {
        return response;
      })
      .catch(this.handleError);
  }

  private handleError(error: Response) {
    return Observable.throw(error.statusText);
  }

}
