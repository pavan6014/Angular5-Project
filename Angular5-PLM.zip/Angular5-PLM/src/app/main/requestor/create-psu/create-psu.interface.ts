export interface CreatePsu {
    offerID: string;
    sequenceNo: string;
    psuType: string;
    product: PSUProduct[];
    specification: Specifications
}

export interface PSUProduct{
    productGroup: string;
    productID: string;
    productName: string;
}

export interface Specifications {
    price: string;
    discountType: string;
    discountDuration: string;
    priceSpecification: string;
    discountValue: string;
}

export interface RemovePSURequest {
    projectCode: string;
    offerID: string;
    psuType: string;
}

export interface AddPSURequest {
    projectCode: string;
    offerID: string;
    psuType: string;
    product: PSUProduct[];
}

export interface SubmitProjectInfo{
    projectCode: string;
}
