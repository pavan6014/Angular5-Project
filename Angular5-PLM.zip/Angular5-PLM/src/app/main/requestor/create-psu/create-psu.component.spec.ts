import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatePsuComponent } from './create-psu.component';

describe('CreatePsuComponent', () => {
  let component: CreatePsuComponent;
  let fixture: ComponentFixture<CreatePsuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatePsuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatePsuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
