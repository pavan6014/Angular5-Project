import { Component, Inject, Input, OnInit, Pipe, PipeTransform, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ViewMarketingProjResponse } from '../requestor.interface';
import { RequestorService } from '../services/requestor.service';
import { RequestorDataService } from '../services/requestor-data.service';
import { KeysPipe } from '../pipes/keys.pipe';



import { Observable } from 'rxjs/Observable';
import { BreadCrumb } from '../../../shared/services/bread-crumb';

@Component({
  selector: 'plm-view-project-details',
  templateUrl: './view-project-details.component.html',
  styleUrls: ['./view-project-details.component.css'],
  providers: [RequestorService]
})
export class ViewProjectDetailsComponent implements OnInit {

  private projectCode: string;
  private showMarketingOffers: boolean;
  private viewDataLoaded: Boolean;
  private projectModelDetails: ViewMarketingProjResponse;
  private sites: string[];


  constructor(private request: RequestorService, private requestorDataService: RequestorDataService) {
    this.showMarketingOffers = false;
    this.viewDataLoaded = false;
    this.sites = [];
  }

  ngOnInit() {
    const reqObj = {
      'projectCode': this.requestorDataService.createViewProjectID,
    };
    this.request.getViewProjectData(reqObj).subscribe(
      data => {
          this.projectCode = data.ProjectCode;
          this.projectModelDetails = data;
          this.viewDataLoaded = true;
          this.updateSites(data);
      },
      error => {
        //console.log("Error :: " + error)
      }
    );
  }

  updateSites(data){
    const createProjectMasterData = this.requestorDataService.getCreateProjectForm();
    for (let i=0; i<data.projectMasterModel.market.length; i++) {
      this.sites.push(createProjectMasterData.mapMarketList[data.projectMasterModel.market[i]]);
    }
  }


  showHideMarketingOffers(){
      this.showMarketingOffers = !this.showMarketingOffers;
  }


}