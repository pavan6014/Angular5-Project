import { Map } from 'rxjs/util/Map';
import { forEach } from '@angular/router/src/utils/collection';
import {
    Component,
    Inject,
    OnInit,
    Pipe,
    PipeTransform,
    ViewChild,
    EventEmitter,
    Output,
    Input,
    OnChanges,
    SimpleChange,
    SimpleChanges
} from '@angular/core';
import { NgForm } from '@angular/forms';
import {
    RequestorResponseInterface,
    RequestorRequestInterface,
    IntakeFormReq,
    AddUpdateProjectResponse
} from '../../../requestor.interface';
import { RequestorService } from '../../../services/requestor.service';
import { RequestorDataService } from '../../../services/requestor-data.service';
import { KeysPipe } from '../../../pipes/keys.pipe';
import {
    FormGroup,
    FormBuilder,
    Validators,
    ReactiveFormsModule,
    FormsModule
} from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { BreadCrumb } from '../../../../../shared/services/bread-crumb';

@Component({
    selector: 'plm-create-project',
    templateUrl: './create-project.component.html',
    providers: [RequestorService]
})
export class CreateProjectComponent implements OnInit, OnChanges {

    private requesterForms: FormGroup;
    private breadCrumbs: BreadCrumb[];
    public formData: RequestorResponseInterface;
    public formDataLoaded: Boolean;
    private projectStartMinDate: Date;
    private projectEndMinDate: Date;
    private isUpdateProject: Boolean;
    private isAllSitesSelected: Boolean;
    private sitesSelected: Boolean;
    private selectSite: Object;
    private addUpdateProject: RequestorRequestInterface;
    private selectedAll: Boolean;
    private sites: string[];
    private showIntakeFormHeader: boolean;

    @ViewChild('createUpdateProjectForm') public createUpdateProjectForm: NgForm;
    @Output() onAddUpdateProject: EventEmitter<AddUpdateProjectResponse> = new EventEmitter<AddUpdateProjectResponse>();
    @Input() editProject: RequestorRequestInterface;
    @Input() addProjectMasterData: RequestorResponseInterface;

    constructor(
        private request: RequestorService,
        private requestorDataService: RequestorDataService,
        private formBuilder: FormBuilder
    ) {
        this.formDataLoaded = false;
        this.addUpdateProject = this.getIntialAddUpdateProject();
        this.getCreateUpdateProjectFormFields();
        this.intializeProjectDate();
        this.breadCrumbs = this.request.getBreadCrumbs();
        this.isUpdateProject = false;
        this.isAllSitesSelected = false;
        this.sitesSelected = true;
        this.selectSite = {};
        this.selectedAll = false;
        this.showIntakeFormHeader = false;
    }

    ngOnInit() { }

    ngOnChanges(changes: SimpleChanges) {
        const editProject: SimpleChange = changes.editProject;
        //console.log('prev value: ', editProject.previousValue);
        //console.log('got name: ', editProject.currentValue);
        if (typeof editProject.currentValue !== 'undefined') {
            this.isUpdateProject = true;
            this.showIntakeFormHeader = true;
            this.addUpdateProject = ((typeof editProject.currentValue !== 'undefined')) ? JSON.parse(JSON.stringify(editProject.currentValue)) : this.getIntialAddUpdateProject();
            this.updateAddUpdateProjectSites();
        }
    }

    getCreateUpdateProjectFormFields() {
        this.request.getCreateUpdateProjectFormData().subscribe(
            data => {
                this.formData = data;
                this.requestorDataService.setCreateProjectForm(data);
                this.formDataLoaded = true;
            },
            error => {
                console.log('Error :: ' + error);
            }
        );
    }

    getIntialAddUpdateProject() {
        let addUpdateProjectObj: RequestorRequestInterface;
        const intakeForm = this.getIntialIntakeForm();
        const intialMap = new Map();
        addUpdateProjectObj = {
            'projectCode': '',
            'projectType': '',
            'projectStatus': '',
            'projectStartDt': '',
            'projectEndDt': '',
            'description': '',
            'sites': [],
            'market': [],
            'status': '',
            'assignedTo': '',
            'mapProjectTypes': intialMap,
            'mapMarketList': intialMap,
            'intakeFormResp': intakeForm
        };
        return addUpdateProjectObj;
    }

    getIntialIntakeForm() {
        let addUpdateData: IntakeFormReq;
        addUpdateData = {
            'intakeFormId': '',
            'addUptierPaths': '',
            'description': '',
            'durationMonths': '',
            'instltnIncFlg': false,
            'instltnPricing': '',
            'prodMustExc': '',
            'prodMustInc': '',
            'prodMustInstlExc': '',
            'prodMustInstlInc': '',
            'prodMustRetainExc': '',
            'prodMustRetainInc': '',
            'products': '',
            'projectName': '',
            'reqstdExpireDate': '',
            'reqstdStartDate': '',
            'reqstorEmail': '',
            'reqstorName': '',
            'stepupAmount': '',
            'intakeChnlModel': 0,
            'stepUpDuration': 0,
            'intakeMktModel': 0,
            'intakeReqPlg': 0,
            'intakeTecode': 0,
            'intakeTgtaud': 0,
            'intakeTirequirement': 0
        }
        return addUpdateData;
    }

    intializeAddUpdateProject(updateData) {
        this.addUpdateProject.projectCode = (typeof updateData.projectCode !== 'undefined') ? (updateData.projectCode) : '';
        this.addUpdateProject.projectType = (typeof updateData.projectType !== 'undefined') ? (updateData.projectType) : '';
        this.addUpdateProject.projectStartDt = (typeof updateData.projectStartDt !== 'undefined') ? (updateData.projectStartDt) : '';
        this.addUpdateProject.projectEndDt = (typeof updateData.projectEndDt !== 'undefined') ? (updateData.projectEndDt) : '';
        this.addUpdateProject.sites = (typeof updateData.sites !== 'undefined') ? (updateData.sites) : [];
        this.addUpdateProject.market = (typeof updateData.market !== 'undefined') ? (updateData.market) : [];
        this.addUpdateProject.description = (typeof updateData.description !== 'undefined') ? (updateData.description) : '';
        this.addUpdateProject.intakeFormResp = (typeof updateData.intakeForm !== 'undefined') ? (updateData.intakeForm) : (this.getIntialIntakeForm());
    }

    intializeProjectDate() {
        const today = new Date();
        const todayDate = today.getDate();
        const todayMonth = today.getMonth();
        const todayYear = today.getFullYear();
        this.projectStartMinDate = new Date(todayYear, todayMonth, todayDate);
        this.projectEndMinDate = new Date(todayYear, todayMonth, todayDate);
    }

    startDateChanged(startDate) {
        const startDateObj = new Date(startDate);
        const endMinDate = Number(startDateObj.getDate()) + 10;
        const endMinMonth = startDateObj.getMonth();
        const endMinYear = startDateObj.getFullYear();
        this.projectEndMinDate = new Date(endMinYear, endMinMonth, endMinDate);
    }

    isAllSitesSelectedCheck() {
        const marketSitesLength = Object.keys(this.formData.mapMarketList).length;
        if (this.addUpdateProject.sites.length === marketSitesLength) {
            this.selectedAll = true;
            return true;
        } else {
            this.selectedAll = false;
            return false;
        }
    }

    isSitesExist(site) {
        if (this.addUpdateProject.sites.indexOf(site.toString()) > -1) {
            return true;
        } else {
            return false;
        }
    }

    selectAll(selectedAll) {
        if (selectedAll) {
            this.addUpdateProject.sites = Object.keys(this.formData.mapMarketList);
            this.isAllSitesSelected = true;
        } else {
            this.addUpdateProject.sites = [];
            this.isAllSitesSelected = false;
        }
        this.validateIsSitesSelected();
    }

    validateIsSitesSelected() {
        if (this.addUpdateProject.sites.length > 0) {
            this.sitesSelected = true;
        } else {
            this.sitesSelected = false;
        }
    }

    addSite(selectSite, siteValue) {
        if (selectSite) {
            this.addUpdateProject.sites.push(siteValue);
            this.sites = this.addUpdateProject.sites;
        } else {
            const sitesVal = JSON.parse(JSON.stringify(this.addUpdateProject.sites));
            if (sitesVal.indexOf(siteValue) > -1) {
                sitesVal.splice(sitesVal.indexOf(siteValue), 1);
            }
            this.addUpdateProject.sites = sitesVal;
            this.sites = sitesVal;
        }
        this.validateIsSitesSelected();
        this.isAllSitesSelectedCheck();
    }

    onAddProjectSubmit(form) {
        const submitData = this.getAddUpdateProjectData();
        this.request.postAddProjectDetails(submitData).subscribe(
            data => {
                this.onAddUpdateProject.emit(data);
                this.isUpdateProject = false;
                this.showIntakeFormHeader = false;
                this.createUpdateProjectForm.reset();
                this.selectedAll = false;
                this.addUpdateProject = this.getIntialAddUpdateProject();
            },
            error => {
                console.log('Error :: ' + error)
            }
        );
    }

    onUpdateProjectSubmit(form) {
        const submitData = this.getAddUpdateProjectData();
        this.request.postUpdateProjectDetails(submitData).subscribe(
            data => {
                this.onAddUpdateProject.emit(data);
                this.isUpdateProject = false;
                this.showIntakeFormHeader = false;
                this.createUpdateProjectForm.reset();
                this.selectedAll = false;
                this.addUpdateProject = this.getIntialAddUpdateProject();
            },
            error => {
                console.log('Error :: ' + error)
            }
        );
    }

    updateAddUpdateProjectSites() {
        for (let i = 0; i < this.addUpdateProject.market.length; i++) {
            this.addUpdateProject.sites.push(this.addUpdateProject.market[i].projSiteMapId.toString());
        }
    }

    getAddUpdateProjectData() {
        const submitData = {
            'projectCode': this.addUpdateProject.projectCode,
            'projectType': this.addUpdateProject.projectType,
            'projectStartDt': this.addUpdateProject.projectStartDt,
            'projectEndDt': this.addUpdateProject.projectEndDt,
            'market': this.getMarketsArray(),
            'description': this.addUpdateProject.description,
            'intakeFormReq': {
                'intakeFormId': this.addUpdateProject.intakeFormResp.intakeFormId,
                'addUptierPaths': this.addUpdateProject.intakeFormResp.addUptierPaths,
                'description': this.addUpdateProject.intakeFormResp.description,
                'durationMonths': this.addUpdateProject.intakeFormResp.durationMonths,
                'instltnIncFlg': this.addUpdateProject.intakeFormResp.instltnIncFlg,
                'instltnPricing': this.addUpdateProject.intakeFormResp.instltnPricing,
                'prodMustExc': this.addUpdateProject.intakeFormResp.prodMustExc,
                'prodMustInc': this.addUpdateProject.intakeFormResp.prodMustInc,
                'prodMustInstlExc': this.addUpdateProject.intakeFormResp.prodMustInstlExc,
                'prodMustInstlInc': this.addUpdateProject.intakeFormResp.prodMustInstlInc,
                'prodMustRetainExc': this.addUpdateProject.intakeFormResp.prodMustRetainExc,
                'prodMustRetainInc': this.addUpdateProject.intakeFormResp.prodMustRetainInc,
                'products': this.addUpdateProject.intakeFormResp.products,
                'projectName': this.addUpdateProject.intakeFormResp.projectName,
                'reqstdExpireDate': this.addUpdateProject.intakeFormResp.reqstdExpireDate,
                'reqstdStartDate': this.addUpdateProject.intakeFormResp.reqstdStartDate,
                'reqstorEmail': this.addUpdateProject.intakeFormResp.reqstorEmail,
                'reqstorName': this.addUpdateProject.intakeFormResp.reqstorName,
                'stepupAmount': this.addUpdateProject.intakeFormResp.stepupAmount,
                'intakeChnlModel': this.addUpdateProject.intakeFormResp.intakeChnlModel,
                'stepUpDuration': this.addUpdateProject.intakeFormResp.stepUpDuration,
                'intakeMktModel': this.addUpdateProject.intakeFormResp.intakeMktModel,
                'intakeReqPlg': this.addUpdateProject.intakeFormResp.intakeReqPlg,
                'intakeTecode': this.addUpdateProject.intakeFormResp.intakeTecode,
                'intakeTgtaud': this.addUpdateProject.intakeFormResp.intakeTgtaud,
                'intakeTirequirement': this.addUpdateProject.intakeFormResp.intakeTirequirement
            }
        }
        return submitData;
    }

    getMarketsArray() {
        const result = [];
        for (let i=0; i<this.addUpdateProject.sites.length; i++) {
            result.push(Number(this.addUpdateProject.sites[i]));
        }
        return result;
    }
}
