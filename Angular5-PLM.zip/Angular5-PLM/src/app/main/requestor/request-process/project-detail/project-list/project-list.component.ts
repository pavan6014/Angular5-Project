import { Component, Inject, OnInit, Pipe, PipeTransform, ViewChild, Input, OnChanges, Output, EventEmitter, SimpleChange, SimpleChanges } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { FetchAllProjects, RequestorRequestInterface, RequestorResponseInterface } from '../../../requestor.interface';
import { RequestorService } from '../../../services/requestor.service';
import { RequestorDataService } from '../../../services/requestor-data.service';
import { KeysPipe } from '../../../pipes/keys.pipe';
import { Observable } from 'rxjs/Observable';


@Component({
  selector: 'plm-project-list',
  templateUrl: './project-list.component.html'
})
export class ProjectListComponent implements OnInit, OnChanges {

  private filterBycode: string;
  private byProjectType: string;
  private byCategory: string;
  private byMarket: string;
  private byStatus: string;
  private byAssignedTo: string;
  private showSearch: boolean;
  private key: string;
  private reverse: boolean;
  private createProjectForm: RequestorResponseInterface;
  @ViewChild('addUserForm') public addUserForm: NgForm;
  @Input() projectDetails: FetchAllProjects[];
  @Output() onEditProject: EventEmitter<RequestorRequestInterface> = new EventEmitter<RequestorRequestInterface>();

  constructor(private request: RequestorService, private requestDataService: RequestorDataService, private router: Router) {

  }


  ngOnInit() {
    this.filterBycode = '';
    this.byProjectType = '';
    this.byCategory = '';
    this.byMarket = '';
    this.byStatus = '';
    this.byAssignedTo = '';
    this.requestDataService.createProjectFormUpdated.subscribe(
      data => {
          this.createProjectForm = data;
          this.modifyProjectDetails();
      },
      error => {
          console.log('Error :: ' + error);
      }
    );
  }

  modifyProjectDetails() {
      const projectList = JSON.parse(JSON.stringify(this.projectDetails));
      for (let i=0; i<projectList.length; i++) {
          const currentProject = projectList[i];
          currentProject.projectTypeVal = this.requestDataService.getCreateProjectForm().mapProjectTypes[currentProject.projectType];
          this.projectDetails[i] = JSON.parse(JSON.stringify(currentProject));
      }
  }

  moveToViewProject(projectCode) {
    this.requestDataService.createViewProjectID = projectCode;
    this.router.navigate(['/plm-work-flow/requestor/view-project-details']);
  }

  ngOnChanges(changes: SimpleChanges) {
    const projectDetails: SimpleChange = changes.projectDetails;
    //console.log('prev value: ', projectDetails.previousValue);
    //console.log('got name: ', projectDetails.currentValue);
    this.projectDetails = ((typeof projectDetails.currentValue !== 'undefined')) ? JSON.parse(JSON.stringify(projectDetails.currentValue)) : [];
  }

  moveToCreatePSU(projectCode) {
    this.requestDataService.createPSUProjectID = projectCode;
    console.log(this.requestDataService.createPSUProjectID);
    this.router.navigate(['/plm-work-flow/requestor/create-psu']);
  }

  sort(key) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  toggleSearchIcon() {
    this.showSearch = !this.showSearch;
  }


  returnBack() {
    this.router.navigate(['']);
  }

  editProject(projectDetail) {
    this.onEditProject.emit(projectDetail.projectCode);
    document.body.scrollTop = document.documentElement.scrollTop = 0;
  }

}
