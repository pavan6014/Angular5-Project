import { Component, Inject, OnInit, Pipe, PipeTransform, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FetchAllProjects, RequestorRequestInterface } from '../requestor.interface';
import { RequestorService } from '../services/requestor.service';
import { RequestorDataService } from '../services/requestor-data.service';
import { KeysPipe } from '../pipes/keys.pipe';
import { FormGroup, FormBuilder, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BlockUI, NgBlockUI } from 'ng-block-ui';


import { Observable } from 'rxjs/Observable';
import { BreadCrumb } from '../../../shared/services/bread-crumb';

@Component({
    selector: 'plm-request-process',
    templateUrl: './request-process.component.html',
    providers: [RequestorService]
})
export class RequestProcessComponent implements OnInit {
    @BlockUI() blockUI: NgBlockUI;

    selectedAll: any;
    requesterForms: FormGroup;
    private projectDetails: FetchAllProjects;
    private projectAdded: Boolean;
    private projectNotAdded: Boolean;
    private addOrupdate: string;
    private addProjectID: string;
    private addUpdateProject: RequestorRequestInterface;
    private editProject: RequestorRequestInterface;
    private updatedSuccessfully: boolean;

    constructor(
        private request: RequestorService,
        private requestorDataService: RequestorDataService,
        private formBuilder: FormBuilder
    ) {
       
        // this.postAllProjectRequest();
        this.getAllProjectDetails();
        this.getPSUTypes();
        this.projectAdded = false;
        this.projectNotAdded = false;
        this.addOrupdate = 'Add';
        this.addProjectID = '';
        this.updatedSuccessfully = false;
        this.blockUI.start('Loading...'); // Start blocking
    }

    ngOnInit() {
        this.requesterForms = this.formBuilder.group({
            projectCode: [null, [Validators.required, Validators.email]],
            projectType: [null, Validators.required],
            category: [null, Validators.required],
            mapMarketList: [null, Validators.required],
            projectStartDt: [null, Validators.required],
            projectEndDt: [null, Validators.required]
        });
    }


  getPSUTypes(){
    this.request.getPSUTypes().subscribe(
      data => {
        //console.log(data);
        this.requestorDataService.psuTypes = data;
      },
      error => {
        //console.log('Error :: ' + error)
      }
    );
  }

    getAllProjectDetails() {
        this.request.getAllProjectDetails().subscribe(
            data => {
                this.projectDetails = data;
                //console.log('test', this.projectDetails);
                this.blockUI.stop();
            },
            error => {
                //console.log('Error :: ' + error);
            }
        );
    }

    // getAllProjectDetailsAddUpdate() {
    //     this.request.getAllProjectDetailsAddUpdate().subscribe(
    //         data => {
    //             this.projectDetails = data;
    //             //console.log('test', this.projectDetails);
    //             this.addOrupdate = 'Add';
    //             this.projectAdded = false;
    //             this.updatedSuccessfully = true;   
    //         },
    //         error => {
    //             //console.log('Error :: ' + error);
    //         }
    //     );
    // }

    onAddUpdateProject(response) {
        this.projectAdded = false;
        this.projectNotAdded = false;
        this.addProjectID = response.projectCode;
        //console.log('Iam here buddy!!!');
        //console.log(this.addOrupdate);
        //console.log(response);
        if (response.actionStatus === 'SUCCESS') {
            //console.log('here');
            this.projectAdded = true;
            this.getAllProjectDetails();
        } else if (response.actionStatus === 'FAIL') {
            this.projectNotAdded = true;
        }
    }

    onEditProject(projectCode) {
        //console.log('Comes here!!!');
        this.projectAdded = false;
        this.projectNotAdded = false;
        this.addOrupdate = 'Update';
        //console.log(projectCode);
        this.request.getEditProjectData(projectCode).subscribe(
            data => {
                this.editProject = data;
                //console.log(this.editProject);
                //console.log('test', this.projectDetails);
            },
            error => {
                //console.log('Error :: ' + error);
            }
        );
    }

    // postAllProjectRequest() {
    //     this.request.postAllProjectRequest().subscribe(
    //         data => {
    //             this.response = data;
    //             //console.log('ddddddccccc', this.response);
    //         },
    //         error => {
    //             //console.log('Error :: ' + error);
    //         }
    //     );
    // }
}
