export const environment = {
  production: true,
  envName: 'prod',
  host: '/ice',
  isDebugMode: false
};

