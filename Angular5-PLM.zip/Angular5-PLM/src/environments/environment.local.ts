export const environment = {
  production: false,
  envName: 'local',
  host: 'http://localhost:8080/ice',
  isDebugMode: true
};
